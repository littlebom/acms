'use client';

import { useState } from 'react';
import { useFormStatus } from 'react-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { updateEvent, createEvent, type EventData } from "@/app/actions/events";
import { type Questionnaire } from "@/app/actions/questions";
import { type SpeakerGroup } from "@/app/actions/speakers";
import { type Schedule } from "@/app/actions/schedule";
import { Loader2, Save, FileText, ArrowLeft, Users, Calendar } from "lucide-react";
import { format } from 'date-fns';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

function SubmitButton({ isCreate }: { isCreate: boolean }) {
    const { pending } = useFormStatus();
    return (
        <Button disabled={pending} type="submit">
            {pending ? (
                <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {isCreate ? 'Creating...' : 'Saving...'}
                </>
            ) : (
                <>
                    <Save className="mr-2 h-4 w-4" />
                    {isCreate ? 'Create Event' : 'Save Changes'}
                </>
            )}
        </Button>
    );
}

// Helper to format date for input type="datetime-local"
function formatDateForInput(date: Date | null | string | undefined) {
    if (!date) return '';
    const d = new Date(date);
    return format(d, "yyyy-MM-dd'T'HH:mm");
}

export function EventForm({
    initialData,
    questionnaires = [],
    speakerGroups = [],
    schedules = []
}: {
    initialData?: EventData | null,
    questionnaires?: Questionnaire[],
    speakerGroups?: SpeakerGroup[],
    schedules?: Schedule[]
}) {
    const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
    const router = useRouter();
    const isCreate = !initialData?.id;

    async function handleSubmit(formData: FormData) {
        setMessage(null);

        let result;
        if (isCreate) {
            result = await createEvent(formData);
        } else {
            result = await updateEvent(formData);
        }

        if (result.error) {
            setMessage({ type: 'error', text: result.error });
        } else {
            if (isCreate) {
                router.push('/admin/conference/events');
            } else {
                setMessage({ type: 'success', text: 'Event settings updated successfully!' });
            }
        }
    }

    return (
        <div className="space-y-6">
            <form action={handleSubmit}>
                {initialData?.id && <input type="hidden" name="id" value={initialData.id} />}

                {/* Hidden inputs to ensure required fields are submitted even if not on the active tab */}
                <input type="hidden" name="name_en" value={initialData?.name_en || ''} />
                <input type="hidden" name="name_th" value={initialData?.name_th || ''} />
                <input type="hidden" name="description" value={initialData?.description || ''} />
                <input type="hidden" name="venue_name" value={initialData?.venue_name || ''} />
                <input type="hidden" name="venue_map_url" value={initialData?.venue_map_url || ''} />
                <input type="hidden" name="start_date" value={formatDateForInput(initialData?.start_date)} />
                <input type="hidden" name="end_date" value={formatDateForInput(initialData?.end_date)} />
                <input type="hidden" name="submission_deadline" value={formatDateForInput(initialData?.submission_deadline)} />
                <input type="hidden" name="registration_deadline" value={formatDateForInput(initialData?.registration_deadline)} />

                <Tabs defaultValue="general" className="w-full">
                    <TabsList className="grid w-full grid-cols-3 mb-6">
                        <TabsTrigger value="general">General Information</TabsTrigger>
                        <TabsTrigger value="resources">Resources & Content</TabsTrigger>
                        <TabsTrigger value="registration">Registration</TabsTrigger>
                    </TabsList>

                    <TabsContent value="general" className="space-y-6">
                        {/* General Info */}
                        <Card>
                            <CardHeader>
                                <CardTitle>General Information</CardTitle>
                                <CardDescription>Basic details about the conference.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="name_en">Event Name (English)</Label>
                                        <Input
                                            id="name_en"
                                            name="name_en"
                                            defaultValue={initialData?.name_en || ''}
                                            required
                                            placeholder="e.g. The 5th International Conference on AI"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="name_th">Event Name (Thai)</Label>
                                        <Input
                                            id="name_th"
                                            name="name_th"
                                            defaultValue={initialData?.name_th || ''}
                                            placeholder="e.g. การประชุมวิชาการระดับนานาชาติ..."
                                        />
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="description">Description</Label>
                                    <Textarea
                                        id="description"
                                        name="description"
                                        defaultValue={initialData?.description || ''}
                                        rows={4}
                                        placeholder="Brief description of the event..."
                                    />
                                </div>
                            </CardContent>
                        </Card>

                        {/* Venue & Location */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Venue & Location</CardTitle>
                                <CardDescription>Where the event will take place.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="venue_name">Venue Name</Label>
                                        <Input
                                            id="venue_name"
                                            name="venue_name"
                                            defaultValue={initialData?.venue_name || ''}
                                            placeholder="e.g. Grand Hall, Bangkok Convention Center"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="venue_map_url">Google Maps URL</Label>
                                        <Input
                                            id="venue_map_url"
                                            name="venue_map_url"
                                            defaultValue={initialData?.venue_map_url || ''}
                                            placeholder="https://maps.google.com/..."
                                        />
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Important Dates */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Important Dates</CardTitle>
                                <CardDescription>Key dates and deadlines.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="start_date">Event Start Date</Label>
                                        <Input
                                            type="datetime-local"
                                            id="start_date"
                                            name="start_date"
                                            defaultValue={formatDateForInput(initialData?.start_date)}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="end_date">Event End Date</Label>
                                        <Input
                                            type="datetime-local"
                                            id="end_date"
                                            name="end_date"
                                            defaultValue={formatDateForInput(initialData?.end_date)}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="submission_deadline">Paper Submission Deadline</Label>
                                        <Input
                                            type="datetime-local"
                                            id="submission_deadline"
                                            name="submission_deadline"
                                            defaultValue={formatDateForInput(initialData?.submission_deadline)}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="registration_deadline">Registration Deadline</Label>
                                        <Input
                                            type="datetime-local"
                                            id="registration_deadline"
                                            name="registration_deadline"
                                            defaultValue={formatDateForInput(initialData?.registration_deadline)}
                                        />
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="resources" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Speakers & Schedule</CardTitle>
                                <CardDescription>Select the content to display for this event.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="space-y-2">
                                    <Label htmlFor="speaker_group_id">Speaker List</Label>
                                    <Select
                                        name="speaker_group_id"
                                        defaultValue={initialData?.speaker_group_id?.toString() || 'none'}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select a speaker list" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="none">-- None --</SelectItem>
                                            {speakerGroups.map(g => (
                                                <SelectItem key={g.id} value={g.id.toString()}>
                                                    {g.name} ({g.member_count} speakers)
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    <p className="text-sm text-slate-500 flex items-center gap-1">
                                        <Users className="h-3 w-3" />
                                        Manage lists in "Conference Hub &gt; Speakers".
                                    </p>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="schedule_id">Event Schedule</Label>
                                    <Select
                                        name="schedule_id"
                                        defaultValue={initialData?.schedule_id?.toString() || 'none'}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select a schedule" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="none">-- None --</SelectItem>
                                            {schedules.map(s => (
                                                <SelectItem key={s.id} value={s.id.toString()}>
                                                    {s.title} ({s.session_count} sessions)
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    <p className="text-sm text-slate-500 flex items-center gap-1">
                                        <Calendar className="h-3 w-3" />
                                        Manage schedules in "Conference Hub &gt; Schedule".
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="registration">
                        <Card>
                            <CardHeader>
                                <CardTitle>Registration Form</CardTitle>
                                <CardDescription>Select the questionnaire to be used during attendee registration.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="registration_form_id">Pre-Event Questionnaire</Label>
                                        <Select
                                            name="registration_form_id"
                                            defaultValue={initialData?.registration_form_id?.toString() || 'none'}
                                        >
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select a questionnaire" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="none">-- None --</SelectItem>
                                                {questionnaires.map(q => (
                                                    <SelectItem key={q.id} value={q.id.toString()}>
                                                        {q.title} ({q.questions_count} questions)
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                        <p className="text-sm text-slate-500 flex items-center gap-1">
                                            <FileText className="h-3 w-3" />
                                            Manage questionnaires in "Engagement &gt; Questionnaires".
                                        </p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>

                {message && (
                    <div className={`mt-6 p-4 rounded-md ${message.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
                        {message.text}
                    </div>
                )}

                <div className="flex justify-end mt-6">
                    <SubmitButton isCreate={isCreate} />
                </div>
            </form>
        </div>
    );
}
