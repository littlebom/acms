'use client';

import { useState } from 'react';
import {
    Plus,
    Calendar,
    MoreVertical,
    Trash2,
    ExternalLink,
    Loader2,
    Pencil
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { createSchedule, updateSchedule, deleteSchedule, type Schedule } from "@/app/actions/schedule";
import { type EventData } from "@/app/actions/events";
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Badge } from "@/components/ui/badge";

export function ScheduleList({
    schedules,
    events
}: {
    schedules: Schedule[],
    events: EventData[]
}) {
    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const [editingSchedule, setEditingSchedule] = useState<Schedule | null>(null);
    const [loading, setLoading] = useState(false);
    const router = useRouter();

    async function handleCreate(formData: FormData) {
        setLoading(true);
        await createSchedule(formData);
        setLoading(false);
        setIsCreateOpen(false);
        router.refresh();
    }

    async function handleUpdate(formData: FormData) {
        setLoading(true);
        await updateSchedule(formData);
        setLoading(false);
        setEditingSchedule(null);
        router.refresh();
    }

    async function handleDelete(id: number) {
        if (confirm('Are you sure you want to delete this schedule?')) {
            await deleteSchedule(id);
            router.refresh();
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-end">
                <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                    <DialogTrigger asChild>
                        <Button>
                            <Plus className="mr-2 h-4 w-4" />
                            Create Schedule
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Create New Schedule</DialogTitle>
                            <DialogDescription>
                                Select an event to create a schedule for.
                            </DialogDescription>
                        </DialogHeader>
                        <form action={handleCreate} className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="event">Event</Label>
                                <Select name="event_id" required>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select an event" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {events.map(event => (
                                            <SelectItem key={event.id} value={event.id.toString()}>
                                                {event.title}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <DialogFooter>
                                <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
                                <Button type="submit" disabled={loading}>
                                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Create Schedule
                                </Button>
                            </DialogFooter>
                        </form>
                    </DialogContent>
                </Dialog>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {schedules.map((schedule) => (
                    <div key={schedule.id} className="bg-white border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-4">
                            <div className="p-2 bg-blue-100 rounded-lg">
                                <Calendar className="h-6 w-6 text-blue-600" />
                            </div>
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon">
                                        <MoreVertical className="h-4 w-4" />
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                    <DropdownMenuItem onClick={() => setEditingSchedule(schedule)}>
                                        <Pencil className="mr-2 h-4 w-4" />
                                        Edit
                                    </DropdownMenuItem>
                                    <DropdownMenuItem className="text-red-600" onClick={() => handleDelete(schedule.id)}>
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        Delete
                                    </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>

                        <h3 className="text-lg font-semibold mb-2">{schedule.title}</h3>
                        <p className="text-sm text-slate-500 mb-4 line-clamp-2">
                            {schedule.description || 'No description'}
                        </p>

                        <div className="flex items-center gap-2 mb-4">
                            <Badge variant="secondary">
                                {schedule.session_count || 0} Sessions
                            </Badge>
                            {schedule.event_title && (
                                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                    {schedule.event_title}
                                </Badge>
                            )}
                        </div>

                        <Link href={`/admin/schedule/${schedule.id}`}>
                            <Button className="w-full" variant="outline">
                                Manage Schedule
                                <ExternalLink className="ml-2 h-4 w-4" />
                            </Button>
                        </Link>
                    </div>
                ))}
            </div>

            {/* Edit Dialog */}
            <Dialog open={!!editingSchedule} onOpenChange={(open) => !open && setEditingSchedule(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Edit Schedule</DialogTitle>
                        <DialogDescription>
                            Update schedule details.
                        </DialogDescription>
                    </DialogHeader>
                    {editingSchedule && (
                        <form action={handleUpdate} className="space-y-4">
                            <input type="hidden" name="id" value={editingSchedule.id} />

                            <div className="space-y-2">
                                <Label htmlFor="edit-title">Title</Label>
                                <Input
                                    id="edit-title"
                                    name="title"
                                    defaultValue={editingSchedule.title}
                                    required
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="edit-description">Description</Label>
                                <Textarea
                                    id="edit-description"
                                    name="description"
                                    defaultValue={editingSchedule.description || ''}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="edit-event">Event</Label>
                                <Select name="event_id" defaultValue={editingSchedule.event_id?.toString() || ''} required>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select an event" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {events.map(event => (
                                            <SelectItem key={event.id} value={event.id.toString()}>
                                                {event.title}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <DialogFooter>
                                <Button type="button" variant="outline" onClick={() => setEditingSchedule(null)}>Cancel</Button>
                                <Button type="submit" disabled={loading}>
                                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Save Changes
                                </Button>
                            </DialogFooter>
                        </form>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}
