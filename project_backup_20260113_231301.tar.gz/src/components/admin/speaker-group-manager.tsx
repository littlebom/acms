'use client';

import { useState } from 'react';
import {
    Plus,
    Trash2,
    Loader2,
    ArrowLeft,
    Search,
    UserPlus,
    Check,
    Pencil,
    Mail,
    FileText,
    Camera
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
    addGroupMember,
    removeGroupMember,
    updateSpeakerDetails,
    createSpeakerUser,
    type SpeakerGroup,
    type SpeakerGroupMember
} from "@/app/actions/speakers";
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";

// Define a local type for potential speakers (users) if not exported
interface PotentialSpeaker {
    id: number;
    first_name: string;
    last_name: string;
    email: string;
    profile_image: string | null;
}

function EditSpeakerForm({
    speaker,
    groupId,
    onClose
}: {
    speaker: SpeakerGroupMember,
    groupId: number,
    onClose: () => void
}) {
    const [loading, setLoading] = useState(false);
    const [imagePreview, setImagePreview] = useState<string | null>(speaker.profile_image);
    const router = useRouter();

    async function handleSubmit(formData: FormData) {
        setLoading(true);
        formData.append('user_id', speaker.user_id.toString());
        formData.append('group_id', groupId.toString());

        await updateSpeakerDetails(formData);

        setLoading(false);
        onClose();
        router.refresh();
    }

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const url = URL.createObjectURL(file);
            setImagePreview(url);
        }
    };

    return (
        <form action={handleSubmit} className="space-y-4">
            <div className="flex justify-center mb-6">
                <div className="relative group">
                    <Avatar className="h-24 w-24 border-2 border-slate-200">
                        <AvatarImage src={imagePreview || undefined} />
                        <AvatarFallback className="text-2xl">{speaker.first_name[0]}</AvatarFallback>
                    </Avatar>
                    <label
                        htmlFor="edit_profile_image"
                        className="absolute bottom-0 right-0 bg-white border rounded-full p-1.5 shadow-sm cursor-pointer hover:bg-slate-50"
                    >
                        <Camera className="h-4 w-4 text-slate-600" />
                        <input
                            type="file"
                            id="edit_profile_image"
                            name="profile_image"
                            accept="image/*"
                            className="hidden"
                            onChange={handleImageChange}
                        />
                    </label>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="first_name">First Name</Label>
                    <Input id="first_name" name="first_name" defaultValue={speaker.first_name} required />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="last_name">Last Name</Label>
                    <Input id="last_name" name="last_name" defaultValue={speaker.last_name} required />
                </div>
            </div>

            <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" name="email" type="email" defaultValue={speaker.email} required />
            </div>

            <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                    id="bio"
                    name="bio"
                    defaultValue={speaker.bio || ''}
                    placeholder="Short biography..."
                    rows={4}
                />
            </div>

            <DialogFooter>
                <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
                <Button type="submit" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Save Changes
                </Button>
            </DialogFooter>
        </form>
    );
}

function CreateSpeakerForm({
    groupId,
    onClose
}: {
    groupId: number,
    onClose: () => void
}) {
    const [loading, setLoading] = useState(false);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const router = useRouter();

    async function handleSubmit(formData: FormData) {
        setLoading(true);
        formData.append('group_id', groupId.toString());

        const result = await createSpeakerUser(formData);

        setLoading(false);
        if (result.error) {
            alert(result.error);
        } else {
            onClose();
            router.refresh();
        }
    }

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const url = URL.createObjectURL(file);
            setImagePreview(url);
        }
    };

    return (
        <form action={handleSubmit} className="space-y-4">
            <div className="flex justify-center mb-6">
                <div className="relative group">
                    <Avatar className="h-24 w-24 border-2 border-slate-200">
                        <AvatarImage src={imagePreview || undefined} />
                        <AvatarFallback className="text-2xl bg-slate-100 text-slate-400">
                            <UserPlus className="h-8 w-8" />
                        </AvatarFallback>
                    </Avatar>
                    <label
                        htmlFor="new_profile_image"
                        className="absolute bottom-0 right-0 bg-white border rounded-full p-1.5 shadow-sm cursor-pointer hover:bg-slate-50"
                    >
                        <Camera className="h-4 w-4 text-slate-600" />
                        <input
                            type="file"
                            id="new_profile_image"
                            name="profile_image"
                            accept="image/*"
                            className="hidden"
                            onChange={handleImageChange}
                        />
                    </label>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="new_first_name">First Name</Label>
                    <Input id="new_first_name" name="first_name" required placeholder="John" />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="new_last_name">Last Name</Label>
                    <Input id="new_last_name" name="last_name" required placeholder="Doe" />
                </div>
            </div>

            <div className="space-y-2">
                <Label htmlFor="new_email">Email</Label>
                <Input id="new_email" name="email" type="email" required placeholder="john@example.com" />
            </div>

            <div className="space-y-2">
                <Label htmlFor="new_password">Password (Optional)</Label>
                <Input id="new_password" name="password" type="password" placeholder="Leave empty for default: Speaker123!" />
            </div>

            <div className="space-y-2">
                <Label htmlFor="new_bio">Bio</Label>
                <Textarea
                    id="new_bio"
                    name="bio"
                    placeholder="Short biography..."
                    rows={3}
                />
            </div>

            <DialogFooter>
                <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
                <Button type="submit" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Create & Add Speaker
                </Button>
            </DialogFooter>
        </form>
    );
}

export function SpeakerGroupManager({
    group,
    members,
    allUsers
}: {
    group: SpeakerGroup,
    members: SpeakerGroupMember[],
    allUsers: PotentialSpeaker[]
}) {
    const [loading, setLoading] = useState(false);
    const [openCombobox, setOpenCombobox] = useState(false);
    const [editingSpeaker, setEditingSpeaker] = useState<SpeakerGroupMember | null>(null);
    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    const router = useRouter();

    async function handleAddMember(userId: number) {
        setLoading(true);
        const result = await addGroupMember(group.id, userId);
        setLoading(false);

        if (result.error) {
            alert(result.error);
        } else {
            setOpenCombobox(false);
            setSearchQuery(""); // Reset search
            router.refresh();
        }
    }

    async function handleRemoveMember(userId: number) {
        if (confirm('Remove this speaker from the group?')) {
            await removeGroupMember(group.id, userId);
            router.refresh();
        }
    }

    // Filter out users who are already members
    const availableUsers = allUsers.filter(user =>
        !members.some(member => member.user_id === user.id)
    );

    // Filter based on search query
    const filteredUsers = availableUsers.filter(user => {
        const query = searchQuery.toLowerCase();
        return (
            user.first_name.toLowerCase().includes(query) ||
            user.last_name.toLowerCase().includes(query) ||
            user.email.toLowerCase().includes(query)
        );
    });

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4">
                <Link href="/admin/speakers">
                    <Button variant="outline" size="icon">
                        <ArrowLeft className="h-4 w-4" />
                    </Button>
                </Link>
                <div>
                    <h2 className="text-2xl font-bold">{group.name}</h2>
                    <p className="text-slate-500">{group.description}</p>
                </div>
            </div>

            <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Members ({members.length})</h3>

                <div className="flex gap-2">
                    <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                        <DialogTrigger asChild>
                            <Button variant="outline">
                                <Plus className="mr-2 h-4 w-4" />
                                <span className="hidden sm:inline">Create New Speaker</span>
                                <span className="sm:hidden">New</span>
                            </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[500px]">
                            <DialogHeader>
                                <DialogTitle>Create New Speaker</DialogTitle>
                                <DialogDescription>
                                    Create a new user account and add them as a speaker.
                                </DialogDescription>
                            </DialogHeader>
                            <CreateSpeakerForm
                                groupId={group.id}
                                onClose={() => setIsCreateOpen(false)}
                            />
                        </DialogContent>
                    </Dialog>

                    <Popover open={openCombobox} onOpenChange={setOpenCombobox}>
                        <PopoverTrigger asChild>
                            <Button>
                                <UserPlus className="mr-2 h-4 w-4" />
                                <span className="hidden sm:inline">Add Existing User</span>
                                <span className="sm:hidden">Add</span>
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-[320px] p-2" align="end">
                            <Input
                                placeholder="Search users by name or email..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="mb-2"
                                autoFocus
                            />
                            <div className="max-h-[300px] overflow-y-auto space-y-1">
                                {filteredUsers.length === 0 ? (
                                    <div className="text-sm text-center text-slate-500 py-4">
                                        No users found.
                                    </div>
                                ) : (
                                    filteredUsers.map((user) => (
                                        <button
                                            key={user.id}
                                            onClick={() => handleAddMember(user.id)}
                                            className="flex items-center w-full p-2 hover:bg-slate-100 rounded-md transition-colors text-left"
                                        >
                                            <Avatar className="h-8 w-8 mr-3 flex-shrink-0">
                                                <AvatarImage src={user.profile_image || undefined} />
                                                <AvatarFallback className="bg-slate-200 text-slate-600">
                                                    {user.first_name[0]}
                                                </AvatarFallback>
                                            </Avatar>
                                            <div className="min-w-0 flex-1">
                                                <div className="text-sm font-medium text-slate-900 truncate">
                                                    {user.first_name} {user.last_name}
                                                </div>
                                                <div className="text-xs text-slate-500 truncate">
                                                    {user.email}
                                                </div>
                                            </div>
                                        </button>
                                    ))
                                )}
                            </div>
                        </PopoverContent>
                    </Popover>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {members.map(member => (
                    <Card key={member.user_id} className="relative group overflow-hidden hover:shadow-md transition-shadow">
                        <CardHeader className="pb-2 text-center relative">
                            <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button
                                    variant="secondary"
                                    size="icon"
                                    className="h-8 w-8 bg-white/90 hover:bg-white shadow-sm"
                                    onClick={() => setEditingSpeaker(member)}
                                >
                                    <Pencil className="h-4 w-4 text-slate-600" />
                                </Button>
                                <Button
                                    variant="destructive"
                                    size="icon"
                                    className="h-8 w-8 shadow-sm"
                                    onClick={() => handleRemoveMember(member.user_id)}
                                >
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>

                            <div className="mx-auto mb-2">
                                <Avatar className="h-20 w-20 border-2 border-white shadow-sm">
                                    <AvatarImage src={member.profile_image || undefined} />
                                    <AvatarFallback className="text-xl bg-slate-100 text-slate-500">
                                        {member.first_name[0]}
                                    </AvatarFallback>
                                </Avatar>
                            </div>
                            <h3 className="font-semibold text-lg truncate px-2">
                                {member.first_name} {member.last_name}
                            </h3>
                            <div className="flex items-center justify-center gap-1 text-sm text-slate-500">
                                <Mail className="h-3 w-3" />
                                <span className="truncate max-w-[180px]">{member.email}</span>
                            </div>
                        </CardHeader>
                        <CardContent className="text-center pt-0 pb-4">
                            {member.bio ? (
                                <p className="text-sm text-slate-600 line-clamp-3 px-2">
                                    {member.bio}
                                </p>
                            ) : (
                                <p className="text-sm text-slate-400 italic">No biography added.</p>
                            )}
                        </CardContent>
                    </Card>
                ))}

                {members.length === 0 && (
                    <div className="col-span-full text-center py-16 border-2 border-dashed rounded-lg text-slate-500 bg-slate-50/50">
                        <UserPlus className="mx-auto h-12 w-12 mb-4 opacity-20" />
                        <h3 className="text-lg font-medium text-slate-900">No speakers yet</h3>
                        <p className="mb-4">Add members to this group to get started.</p>
                    </div>
                )}
            </div>

            {/* Edit Speaker Dialog */}
            <Dialog open={!!editingSpeaker} onOpenChange={(open) => !open && setEditingSpeaker(null)}>
                <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                        <DialogTitle>Edit Speaker Details</DialogTitle>
                        <DialogDescription>
                            Update profile information for this speaker.
                        </DialogDescription>
                    </DialogHeader>
                    {editingSpeaker && (
                        <EditSpeakerForm
                            speaker={editingSpeaker}
                            groupId={group.id}
                            onClose={() => setEditingSpeaker(null)}
                        />
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}
