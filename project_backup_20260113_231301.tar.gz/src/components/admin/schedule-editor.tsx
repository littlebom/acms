'use client';

import { useState, useMemo, useEffect } from 'react';
import { format, addDays, parseISO, isSameDay } from 'date-fns';
import {
    Plus,
    MoreVertical,
    Pencil,
    Trash2,
    Calendar,
    MapPin,
    Loader2,
    ArrowLeft,
    Clock,
    CalendarPlus,
    LayoutGrid,
    X,
    Settings,
    User,
    Check,
    Paperclip,
    FileText,
    UserPlus
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
    createSession,
    updateSession,
    deleteSession,
    updateScheduleSettings,
    deleteSessionAttachment,
    type Session,
    type Schedule,
    type ScheduleSettings
} from "@/app/actions/schedule";
import { Badge } from "@/components/ui/badge";
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

// Type for Speaker (User)
interface Speaker {
    id: number;
    first_name: string;
    last_name: string;
    email?: string;
    profile_image: string | null;
}

const SESSION_TYPES = [
    { value: 'keynote', label: 'Keynote', color: 'bg-purple-100 text-purple-800 border-purple-200' },
    { value: 'panel', label: 'Panel Discussion', color: 'bg-blue-100 text-blue-800 border-blue-200' },
    { value: 'workshop', label: 'Workshop', color: 'bg-green-100 text-green-800 border-green-200' },
    { value: 'presentation', label: 'Paper Presentation', color: 'bg-orange-100 text-orange-800 border-orange-200' },
    { value: 'break', label: 'Break / Networking', color: 'bg-slate-100 text-slate-800 border-slate-200' },
];

function DayForm({
    date,
    existingDays,
    onSubmit,
    onClose
}: {
    date?: string,
    existingDays: string[],
    onSubmit: (newDate: string) => Promise<void>,
    onClose: () => void
}) {
    const [loading, setLoading] = useState(false);
    const [selectedDate, setSelectedDate] = useState(date || format(new Date(), 'yyyy-MM-dd'));

    async function handleSubmit(e: React.FormEvent) {
        e.preventDefault();
        if (existingDays.includes(selectedDate) && selectedDate !== date) {
            alert('This date already exists in the schedule.');
            return;
        }
        setLoading(true);
        await onSubmit(selectedDate);
        setLoading(false);
        onClose();
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="day-date">Date</Label>
                <Input
                    type="date"
                    id="day-date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    required
                />
            </div>
            <DialogFooter>
                <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
                <Button type="submit" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {date ? 'Update Date' : 'Add Date'}
                </Button>
            </DialogFooter>
        </form>
    );
}

function SessionForm({
    session,
    scheduleId,
    defaultDate,
    defaultRoom,
    allSpeakers,
    onClose
}: {
    session?: Session | null,
    scheduleId: number,
    defaultDate?: string,
    defaultRoom?: string,
    allSpeakers: Speaker[],
    onClose: () => void
}) {
    const [loading, setLoading] = useState(false);
    const [selectedSpeakers, setSelectedSpeakers] = useState<number[]>(
        session?.speakers?.map(s => s.id) || []
    );
    const [openCombobox, setOpenCombobox] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    const router = useRouter();

    // ... (rest of the code unchanged: baseDate, handleSubmit, formatTime, toggleSpeaker, handleDeleteAttachment) ...

    // Determine the base date for this session
    const baseDate = session
        ? format(new Date(session.start_time), 'yyyy-MM-dd')
        : (defaultDate || format(new Date(), 'yyyy-MM-dd'));

    async function handleSubmit(formData: FormData) {
        setLoading(true);
        formData.append('schedule_id', scheduleId.toString());

        // Construct full ISO datetime strings from time inputs
        const startTimeInput = formData.get('start_time_input') as string;
        const endTimeInput = formData.get('end_time_input') as string;

        if (startTimeInput) {
            formData.set('start_time', `${baseDate}T${startTimeInput}`);
        }
        if (endTimeInput) {
            formData.set('end_time', `${baseDate}T${endTimeInput}`);
        }

        // Append selected speakers
        selectedSpeakers.forEach(id => formData.append('speakers', id.toString()));

        if (session) {
            formData.append('id', session.id.toString());
            await updateSession(formData);
        } else {
            await createSession(formData);
        }
        setLoading(false);
        onClose();
    }

    // Helper to format time for input (HH:mm)
    const formatTime = (date?: Date | string) => {
        if (!date) return '09:00';
        return format(new Date(date), 'HH:mm');
    };

    const toggleSpeaker = (speakerId: number) => {
        setSelectedSpeakers(prev =>
            prev.includes(speakerId)
                ? prev.filter(id => id !== speakerId)
                : [...prev, speakerId]
        );
    };

    const handleDeleteAttachment = async (attachmentId: number) => {
        if (confirm('Delete this file?')) {
            await deleteSessionAttachment(attachmentId, scheduleId);
            router.refresh();
        }
    };

    // Filter speakers based on search query
    const filteredSpeakers = allSpeakers.filter(speaker => {
        const query = searchQuery.toLowerCase();
        return (
            speaker.first_name.toLowerCase().includes(query) ||
            speaker.last_name.toLowerCase().includes(query) ||
            (speaker.email && speaker.email.toLowerCase().includes(query))
        );
    });

    return (
        <form action={handleSubmit} className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="title">Session Title</Label>
                <Input
                    id="title"
                    name="title"
                    defaultValue={session?.title}
                    required
                    placeholder="e.g. Opening Keynote"
                />
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="start_time_input">Start Time</Label>
                    <Input
                        type="time"
                        id="start_time_input"
                        name="start_time_input"
                        defaultValue={formatTime(session?.start_time)}
                        required
                    />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="end_time_input">End Time</Label>
                    <Input
                        type="time"
                        id="end_time_input"
                        name="end_time_input"
                        defaultValue={formatTime(session?.end_time)}
                        required
                    />
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="room">Room / Location</Label>
                    <Input
                        id="room"
                        name="room"
                        defaultValue={session?.room || defaultRoom || ''}
                        placeholder="e.g. Grand Hall A"
                    />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="type">Session Type</Label>
                    <Select name="type" defaultValue={session?.type || 'presentation'}>
                        <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                            {SESSION_TYPES.map(t => (
                                <SelectItem key={t.value} value={t.value}>
                                    {t.label}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>

            <div className="space-y-2">
                <Label>Speakers</Label>

                {/* Selected Speakers List (More explicit Add/Delete) */}
                <div className="space-y-2 mb-2">
                    {selectedSpeakers.length > 0 ? (
                        selectedSpeakers.map(id => {
                            const speaker = allSpeakers.find(s => s.id === id);
                            if (!speaker) return null;
                            return (
                                <div key={id} className="flex items-center justify-between p-2 border rounded-md bg-slate-50">
                                    <div className="flex items-center gap-3">
                                        <Avatar>
                                            <AvatarImage src={speaker.profile_image || undefined} />
                                            <AvatarFallback>{speaker.first_name[0]}</AvatarFallback>
                                        </Avatar>
                                        <div>
                                            <p className="text-sm font-medium">{speaker.first_name} {speaker.last_name}</p>
                                            <p className="text-xs text-slate-500">{speaker.email}</p>
                                        </div>
                                    </div>
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                        onClick={() => toggleSpeaker(id)}
                                    >
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </div>
                            );
                        })
                    ) : (
                        <div className="text-sm text-slate-500 italic p-2 border border-dashed rounded-md text-center">
                            No speakers selected yet.
                        </div>
                    )}
                </div>

                <Popover open={openCombobox} onOpenChange={setOpenCombobox}>
                    <PopoverTrigger asChild>
                        <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={openCombobox}
                            className="w-full justify-center text-blue-600 border-blue-200 hover:bg-blue-50"
                        >
                            <UserPlus className="mr-2 h-4 w-4" />
                            Add Speaker
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[400px] p-2" align="start">
                        <Input
                            placeholder="Search speakers..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="mb-2"
                            autoFocus
                        />
                        <div className="max-h-[300px] overflow-y-auto space-y-1">
                            {filteredSpeakers.length === 0 ? (
                                <div className="text-sm text-center text-slate-500 py-4">
                                    No speaker found.
                                </div>
                            ) : (
                                filteredSpeakers.map((speaker) => (
                                    <button
                                        key={speaker.id}
                                        onClick={() => {
                                            toggleSpeaker(speaker.id);
                                            setOpenCombobox(false);
                                        }}
                                        className="flex items-center w-full p-2 hover:bg-slate-100 rounded-md transition-colors text-left"
                                    >
                                        <div className={cn(
                                            "mr-2 flex items-center justify-center w-4 h-4 rounded-sm border border-primary",
                                            selectedSpeakers.includes(speaker.id) ? "bg-primary text-primary-foreground" : "opacity-50"
                                        )}>
                                            {selectedSpeakers.includes(speaker.id) && <Check className="h-3 w-3" />}
                                        </div>
                                        <Avatar className="h-6 w-6 mr-2">
                                            <AvatarImage src={speaker.profile_image || undefined} />
                                            <AvatarFallback>{speaker.first_name[0]}</AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1 min-w-0">
                                            <div className="text-sm font-medium truncate">
                                                {speaker.first_name} {speaker.last_name}
                                            </div>
                                        </div>
                                    </button>
                                ))
                            )}
                        </div>
                    </PopoverContent>
                </Popover>
            </div>

            <div className="space-y-2">
                <Label htmlFor="files">Attachments (PDF, Slides)</Label>
                <Input
                    id="files"
                    name="files"
                    type="file"
                    multiple
                    accept=".pdf,.ppt,.pptx,.doc,.docx"
                />

                {/* Existing Attachments */}
                {session?.attachments && session.attachments.length > 0 && (
                    <div className="mt-2 space-y-2">
                        {session.attachments.map(file => (
                            <div key={file.id} className="flex items-center justify-between p-2 border rounded bg-slate-50 text-sm">
                                <div className="flex items-center gap-2 truncate">
                                    <FileText className="h-4 w-4 text-slate-500" />
                                    <a href={file.file_url} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline truncate max-w-[200px]">
                                        {file.file_name}
                                    </a>
                                </div>
                                <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6 text-red-500"
                                    onClick={() => handleDeleteAttachment(file.id)}
                                >
                                    <X className="h-4 w-4" />
                                </Button>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                    id="description"
                    name="description"
                    defaultValue={session?.description || ''}
                    placeholder="Brief description of the session..."
                />
            </div>

            <DialogFooter>
                <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
                <Button type="submit" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {session ? 'Update Session' : 'Create Session'}
                </Button>
            </DialogFooter>
        </form>
    );
}

export function ScheduleEditor({
    schedule,
    sessions,
    allSpeakers
}: {
    schedule: Schedule,
    sessions: Session[],
    allSpeakers: Speaker[]
}) {
    const [isCreateSessionOpen, setIsCreateSessionOpen] = useState(false);
    const [isDayFormOpen, setIsDayFormOpen] = useState(false);
    const [editingDay, setEditingDay] = useState<string | null>(null);
    const [editingSession, setEditingSession] = useState<Session | null>(null);
    const [activeTab, setActiveTab] = useState<string>("");
    const [targetDate, setTargetDate] = useState<string | undefined>(undefined);
    const [targetRoom, setTargetRoom] = useState<string | undefined>(undefined);
    const router = useRouter();

    // Parse settings
    const settings: ScheduleSettings = typeof schedule.settings === 'string'
        ? JSON.parse(schedule.settings)
        : (schedule.settings || { days: [], rooms: [] });

    const days = settings.days || [];
    const rooms = settings.rooms || [];

    // Initialize active tab
    useEffect(() => {
        if (activeTab === "" && days.length > 0) {
            setActiveTab(days[0]);
        }
    }, [days, activeTab]);

    // Group sessions by Date and Room
    const sessionsByDateAndRoom = useMemo(() => {
        const groups: Record<string, Record<string, Session[]>> = {};

        sessions.forEach(session => {
            const dateKey = format(new Date(session.start_time), 'yyyy-MM-dd');
            const roomKey = session.room || 'Unassigned';

            if (!groups[dateKey]) groups[dateKey] = {};
            if (!groups[dateKey][roomKey]) groups[dateKey][roomKey] = [];

            groups[dateKey][roomKey].push(session);
        });

        return groups;
    }, [sessions]);

    // Actions
    async function handleAddDay(newDate: string) {
        const newSettings = {
            ...settings,
            days: [...days, newDate].sort()
        };
        await updateScheduleSettings(schedule.id, newSettings);
        setActiveTab(newDate);
    }

    async function handleUpdateDay(newDate: string) {
        if (!editingDay) return;
        const newSettings = {
            ...settings,
            days: days.map(d => d === editingDay ? newDate : d).sort()
        };
        await updateScheduleSettings(schedule.id, newSettings);
        setActiveTab(newDate);
    }

    async function handleAddRoom() {
        const roomName = prompt("Enter room name:");
        if (roomName && !rooms.includes(roomName)) {
            const newSettings = {
                ...settings,
                rooms: [...rooms, roomName]
            };
            await updateScheduleSettings(schedule.id, newSettings);
        }
    }

    async function handleRemoveDay(dateToRemove: string) {
        if (confirm(`Remove Day ${dateToRemove}? Sessions on this day will remain but won't be visible in this tab.`)) {
            const newSettings = {
                ...settings,
                days: days.filter(d => d !== dateToRemove)
            };
            await updateScheduleSettings(schedule.id, newSettings);
            if (activeTab === dateToRemove) {
                setActiveTab(newSettings.days[0] || "");
            }
        }
    }

    async function handleRemoveRoom(roomToRemove: string) {
        if (confirm(`Remove Room ${roomToRemove}? Sessions in this room will remain but won't be visible in this column.`)) {
            const newSettings = {
                ...settings,
                rooms: rooms.filter(r => r !== roomToRemove)
            };
            await updateScheduleSettings(schedule.id, newSettings);
        }
    }

    async function handleDeleteSession(id: number) {
        if (confirm('Are you sure you want to delete this session?')) {
            await deleteSession(id);
            router.refresh();
        }
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Link href="/admin/schedule">
                        <Button variant="outline" size="icon">
                            <ArrowLeft className="h-4 w-4" />
                        </Button>
                    </Link>
                    <div>
                        <h2 className="text-2xl font-bold">{schedule.title}</h2>
                        <p className="text-slate-500">{schedule.description}</p>
                    </div>
                </div>
                <Button onClick={() => setIsDayFormOpen(true)}>
                    <CalendarPlus className="mr-2 h-4 w-4" />
                    Add Day
                </Button>
            </div>

            {days.length === 0 ? (
                <div className="text-center py-12 border rounded-lg bg-slate-50 text-slate-500">
                    <Calendar className="mx-auto h-12 w-12 mb-4 opacity-50" />
                    <p className="mb-4">No days configured yet.</p>
                    <Button onClick={() => setIsDayFormOpen(true)}>
                        <Plus className="mr-2 h-4 w-4" />
                        Start by Adding a Day
                    </Button>
                </div>
            ) : (
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                    <div className="flex items-center justify-between mb-4">
                        <TabsList className="w-full justify-start overflow-x-auto bg-transparent p-0 h-auto gap-2">
                            {days.map((date, index) => (
                                <div key={date} className="relative group">
                                    <TabsTrigger
                                        value={date}
                                        className="data-[state=active]:bg-slate-100 data-[state=active]:text-slate-900 border bg-white px-4 py-2 h-auto flex flex-col items-start gap-1 min-w-[120px] pr-8"
                                    >
                                        <span className="font-semibold">Day {index + 1}</span>
                                        <span className="text-xs font-normal opacity-70">
                                            {format(new Date(date), 'MMM d, yyyy')}
                                        </span>
                                    </TabsTrigger>

                                    {/* Day Actions Dropdown */}
                                    <div className="absolute top-1 right-1">
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" size="icon" className="h-6 w-6 opacity-50 hover:opacity-100">
                                                    <MoreVertical className="h-3 w-3" />
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent>
                                                <DropdownMenuItem onClick={() => setEditingDay(date)}>
                                                    <Pencil className="mr-2 h-4 w-4" />
                                                    Edit Date
                                                </DropdownMenuItem>
                                                <DropdownMenuItem className="text-red-600" onClick={() => handleRemoveDay(date)}>
                                                    <Trash2 className="mr-2 h-4 w-4" />
                                                    Remove Day
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </div>
                                </div>
                            ))}
                        </TabsList>
                    </div>

                    {days.map(date => (
                        <TabsContent key={date} value={date} className="space-y-6 mt-0">
                            {/* Room Columns */}
                            <div className="flex gap-4 overflow-x-auto pb-4">
                                {rooms.map(room => (
                                    <div key={room} className="min-w-[300px] w-[300px] flex-shrink-0 bg-slate-50 rounded-lg border flex flex-col">
                                        {/* Column Header */}
                                        <div className="p-3 border-b bg-white rounded-t-lg flex justify-between items-center sticky top-0">
                                            <h3 className="font-semibold text-slate-700 flex items-center gap-2">
                                                <MapPin className="h-4 w-4 text-slate-400" />
                                                {room}
                                            </h3>
                                            <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-red-500" onClick={() => handleRemoveRoom(room)}>
                                                <X className="h-3 w-3" />
                                            </Button>
                                        </div>

                                        {/* Sessions List */}
                                        <div className="p-3 space-y-3 flex-1 min-h-[200px]">
                                            {sessionsByDateAndRoom[date]?.[room]?.map(session => (
                                                <div
                                                    key={session.id}
                                                    className={`bg-white border rounded-md p-3 shadow-sm hover:shadow-md transition-shadow relative group cursor-pointer ${SESSION_TYPES.find(t => t.value === session.type)?.color.replace('bg-', 'border-l-4 border-l-') || ''
                                                        }`}
                                                    onClick={() => setEditingSession(session)}
                                                >
                                                    <div className="flex justify-between items-start mb-1">
                                                        <Badge variant="outline" className="text-[10px] px-1 py-0 h-5 bg-white/50">
                                                            {SESSION_TYPES.find(t => t.value === session.type)?.label}
                                                        </Badge>
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            className="h-5 w-5 -mr-1 -mt-1 opacity-0 group-hover:opacity-100"
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                handleDeleteSession(session.id);
                                                            }}
                                                        >
                                                            <Trash2 className="h-3 w-3 text-red-500" />
                                                        </Button>
                                                    </div>

                                                    <h4 className="font-bold text-sm text-slate-900 mb-1 leading-tight">{session.title}</h4>

                                                    {/* Speakers Display */}
                                                    {session.speakers && session.speakers.length > 0 && (
                                                        <div className="flex flex-wrap gap-1 mt-2">
                                                            {session.speakers.map(speaker => (
                                                                <div key={speaker.id} className="flex items-center gap-1 text-xs text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded-full">
                                                                    <Avatar className="h-3 w-3">
                                                                        <AvatarImage src={speaker.profile_image || undefined} />
                                                                        <AvatarFallback className="text-[6px]">{speaker.first_name[0]}</AvatarFallback>
                                                                    </Avatar>
                                                                    <span className="truncate max-w-[80px]">{speaker.first_name} {speaker.last_name}</span>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    )}

                                                    {/* Attachments Icon */}
                                                    {session.attachments && session.attachments.length > 0 && (
                                                        <div className="flex items-center gap-1 mt-2 text-xs text-blue-600">
                                                            <Paperclip className="h-3 w-3" />
                                                            <span>{session.attachments.length} file(s)</span>
                                                        </div>
                                                    )}

                                                    <div className="flex items-center gap-1 text-xs text-slate-500 mt-2">
                                                        <Clock className="h-3 w-3" />
                                                        {format(new Date(session.start_time), 'HH:mm')} - {format(new Date(session.end_time), 'HH:mm')}
                                                    </div>
                                                </div>
                                            ))}

                                            <Button
                                                variant="ghost"
                                                className="w-full border-2 border-dashed border-slate-200 text-slate-400 hover:text-slate-600 hover:border-slate-300"
                                                onClick={() => {
                                                    setTargetDate(date);
                                                    setTargetRoom(room);
                                                    setIsCreateSessionOpen(true);
                                                }}
                                            >
                                                <Plus className="mr-2 h-4 w-4" />
                                                Add Session
                                            </Button>
                                        </div>
                                    </div>
                                ))}

                                {/* Add Room Column */}
                                <div className="min-w-[300px] w-[300px] flex-shrink-0 flex items-center justify-center border-2 border-dashed border-slate-200 rounded-lg bg-slate-50/50">
                                    <Button variant="ghost" onClick={handleAddRoom} className="h-full w-full">
                                        <div className="flex flex-col items-center gap-2 text-slate-400">
                                            <LayoutGrid className="h-8 w-8" />
                                            <span>Add Room Column</span>
                                        </div>
                                    </Button>
                                </div>
                            </div>
                        </TabsContent>
                    ))}
                </Tabs>
            )}

            {/* Day Form Dialog */}
            <Dialog open={isDayFormOpen || !!editingDay} onOpenChange={(open) => {
                if (!open) {
                    setIsDayFormOpen(false);
                    setEditingDay(null);
                }
            }}>
                <DialogContent className="sm:max-w-[400px]">
                    <DialogHeader>
                        <DialogTitle>{editingDay ? 'Edit Day' : 'Add New Day'}</DialogTitle>
                        <DialogDescription>
                            Select the date for this schedule day.
                        </DialogDescription>
                    </DialogHeader>
                    <DayForm
                        date={editingDay || undefined}
                        existingDays={days}
                        onSubmit={editingDay ? handleUpdateDay : handleAddDay}
                        onClose={() => {
                            setIsDayFormOpen(false);
                            setEditingDay(null);
                        }}
                    />
                </DialogContent>
            </Dialog>

            {/* Session Form Dialog */}
            <Dialog open={isCreateSessionOpen || !!editingSession} onOpenChange={(open) => {
                if (!open) {
                    setIsCreateSessionOpen(false);
                    setEditingSession(null);
                    setTargetDate(undefined);
                    setTargetRoom(undefined);
                }
            }}>
                <DialogContent className="sm:max-w-[600px]">
                    <DialogHeader>
                        <DialogTitle>{editingSession ? 'Edit Session' : 'Add New Session'}</DialogTitle>
                        <DialogDescription>
                            {editingSession ? 'Update session details.' : `Create a session for ${targetRoom} on ${targetDate ? format(new Date(targetDate), 'MMM d') : ''}.`}
                        </DialogDescription>
                    </DialogHeader>
                    <SessionForm
                        session={editingSession}
                        scheduleId={schedule.id}
                        defaultDate={targetDate}
                        defaultRoom={targetRoom}
                        allSpeakers={allSpeakers}
                        onClose={() => {
                            setIsCreateSessionOpen(false);
                            setEditingSession(null);
                            setTargetDate(undefined);
                            setTargetRoom(undefined);
                        }}
                    />
                </DialogContent>
            </Dialog>
        </div>
    );
}
