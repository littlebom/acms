'use client';

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GraduationCap, Calendar, Settings2 } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface AcademicSettingsTabProps {
    settings: any;
    setSettings: (settings: any) => void;
}

export function AcademicSettingsTab({ settings, setSettings }: AcademicSettingsTabProps) {

    // Helper to handle date changes (input type="date" returns YYYY-MM-DD string)
    const handleDateChange = (field: string, value: string) => {
        setSettings({ ...settings, [field]: value });
    };

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <GraduationCap className="h-5 w-5 text-indigo-600" />
                        Conference Information
                    </CardTitle>
                    <CardDescription>
                        General settings for the academic paper submission system.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid gap-2">
                        <Label htmlFor="academicConferenceName">Conference/Journal Name</Label>
                        <Input
                            id="academicConferenceName"
                            value={settings.academicConferenceName || ''}
                            onChange={(e) => setSettings({ ...settings, academicConferenceName: e.target.value })}
                            placeholder="e.g. AMS International Conference 2026"
                        />
                        <p className="text-[11px] text-slate-500">This name will appear on paper headers and email notifications.</p>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Calendar className="h-5 w-5 text-indigo-600" />
                        Important Dates
                    </CardTitle>
                    <CardDescription>
                        Set key deadlines for the submission and review process.
                    </CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="academicSubmissionDeadline">Submission Deadline</Label>
                        <Input
                            id="academicSubmissionDeadline"
                            type="date"
                            value={settings.academicSubmissionDeadline ? new Date(settings.academicSubmissionDeadline).toISOString().split('T')[0] : ''}
                            onChange={(e) => handleDateChange('academicSubmissionDeadline', e.target.value)}
                        />
                        <p className="text-[11px] text-slate-500">Submissions will be automatically closed after this date.</p>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="academicReviewDeadline">Review Deadline</Label>
                        <Input
                            id="academicReviewDeadline"
                            type="date"
                            value={settings.academicReviewDeadline ? new Date(settings.academicReviewDeadline).toISOString().split('T')[0] : ''}
                            onChange={(e) => handleDateChange('academicReviewDeadline', e.target.value)}
                        />
                        <p className="text-[11px] text-slate-500">Target date for reviewers to complete their evaluations.</p>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Settings2 className="h-5 w-5 text-indigo-600" />
                        Review Process
                    </CardTitle>
                    <CardDescription>
                        Configure how the peer review system operates.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid gap-2 max-w-md">
                        <Label htmlFor="academicReviewType">Review Type</Label>
                        <Select
                            value={settings.academicReviewType || 'double_blind'}
                            onValueChange={(val) => setSettings({ ...settings, academicReviewType: val })}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder="Select review type" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="double_blind">Double Blind (Both Anonymous)</SelectItem>
                                <SelectItem value="single_blind">Single Blind (Reviewer Anonymous)</SelectItem>
                                <SelectItem value="open">Open Review (Both Visible)</SelectItem>
                            </SelectContent>
                        </Select>
                        <div className="text-[11px] text-slate-500 pt-1">
                            <ul className="list-disc list-inside space-y-1">
                                <li><strong>Double Blind:</strong> Authors don't know reviewers, Reviewers don't know authors.</li>
                                <li><strong>Single Blind:</strong> Authors don't know reviewers, Reviewers see author names.</li>
                            </ul>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
