'use client';

import { useState } from 'react';
import Link from 'next/link';
import {
    Plus,
    MoreVertical,
    Trash2,
    Loader2,
    Users,
    ExternalLink
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { createSpeakerGroup, deleteSpeakerGroup, type SpeakerGroup } from "@/app/actions/speakers";
import { type EventData } from "@/app/actions/events";
import { Badge } from "@/components/ui/badge";
import { useRouter } from 'next/navigation';

function GroupForm({ events, onClose }: { events: EventData[], onClose: () => void }) {
    const [loading, setLoading] = useState(false);

    async function handleSubmit(formData: FormData) {
        setLoading(true);
        await createSpeakerGroup(formData);
        setLoading(false);
        onClose();
    }

    return (
        <form action={handleSubmit} className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="event">Event</Label>
                <Select name="event_id" required>
                    <SelectTrigger>
                        <SelectValue placeholder="Select an event" />
                    </SelectTrigger>
                    <SelectContent>
                        {events.map(event => (
                            <SelectItem key={event.id} value={event.id.toString()}>
                                {event.title}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
            <DialogFooter>
                <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
                <Button type="submit" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Create Group
                </Button>
            </DialogFooter>
        </form>
    );
}

export function SpeakerGroupList({
    groups,
    events
}: {
    groups: SpeakerGroup[],
    events: EventData[]
}) {
    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const router = useRouter();

    async function handleDelete(id: number) {
        if (confirm('Are you sure you want to delete this group?')) {
            await deleteSpeakerGroup(id);
            router.refresh();
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Speaker Lists</h2>
                <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                    <DialogTrigger asChild>
                        <Button>
                            <Plus className="mr-2 h-4 w-4" />
                            Create New List
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[500px]">
                        <DialogHeader>
                            <DialogTitle>Create Speaker List</DialogTitle>
                            <DialogDescription>
                                Select an event to create a speaker list for.
                            </DialogDescription>
                        </DialogHeader>
                        <GroupForm events={events} onClose={() => setIsCreateOpen(false)} />
                    </DialogContent>
                </Dialog>
            </div>

            {groups.length === 0 ? (
                <div className="text-center py-12 border rounded-lg bg-slate-50 text-slate-500">
                    <Users className="mx-auto h-12 w-12 mb-4 opacity-50" />
                    <p>No speaker lists created yet.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {groups.map(group => (
                        <div key={group.id} className="bg-white border rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow relative group">
                            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" size="icon" className="h-8 w-8">
                                            <MoreVertical className="h-4 w-4" />
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                        <DropdownMenuItem className="text-red-600" onClick={() => handleDelete(group.id)}>
                                            <Trash2 className="mr-2 h-4 w-4" />
                                            Delete
                                        </DropdownMenuItem>
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </div>

                            <div className="mb-4">
                                <h3 className="font-semibold text-lg truncate pr-6">{group.name}</h3>
                                <p className="text-sm text-slate-500 line-clamp-2 h-10">
                                    {group.description || 'No description'}
                                </p>
                            </div>

                            <div className="flex items-center justify-between mt-4 pt-4 border-t">
                                <div className="flex items-center gap-2">
                                    <Badge variant="secondary">
                                        {group.member_count} Speakers
                                    </Badge>
                                    {group.event_title && (
                                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 truncate max-w-[120px]">
                                            {group.event_title}
                                        </Badge>
                                    )}
                                </div>
                                <Link href={`/admin/speakers/${group.id}`}>
                                    <Button size="sm" variant="outline">
                                        Manage
                                        <ExternalLink className="ml-2 h-3 w-3" />
                                    </Button>
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}
