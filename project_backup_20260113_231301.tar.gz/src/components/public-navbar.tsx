import Link from "next/link";
import { Button } from "@/components/ui/button";

export function PublicNavbar() {
    return (
        <nav className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-50">
            <div className="container mx-auto px-4 h-16 flex items-center justify-between">
                <Link href="/" className="text-2xl font-bold text-primary">
                    ACMS
                </Link>

                <div className="hidden md:flex items-center gap-6">
                    <Link href="/" className="text-sm font-medium hover:text-primary transition-colors">
                        Home
                    </Link>
                    <Link href="/about" className="text-sm font-medium hover:text-primary transition-colors">
                        About
                    </Link>
                    <Link href="/schedule" className="text-sm font-medium hover:text-primary transition-colors">
                        Schedule
                    </Link>
                    <Link href="/speakers" className="text-sm font-medium hover:text-primary transition-colors">
                        Speakers
                    </Link>
                    <Link href="/news" className="text-sm font-medium hover:text-primary transition-colors">
                        News
                    </Link>
                    <Link href="/contact" className="text-sm font-medium hover:text-primary transition-colors">
                        Contact
                    </Link>
                </div>

                <div className="flex items-center gap-4">
                    <Link href="/login">
                        <Button variant="ghost">Login</Button>
                    </Link>
                    <Link href="/register">
                        <Button>Register</Button>
                    </Link>
                </div>
            </div>
        </nav>
    );
}
