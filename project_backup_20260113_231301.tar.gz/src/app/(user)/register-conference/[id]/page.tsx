import { getAvailableTickets, getUserRegistration } from "@/app/actions/user-registration";
import { getEvent } from "@/app/actions/events";
import { getQuestions } from "@/app/actions/questions";
import { UserRegistrationForm } from "@/components/user/registration-form";
import { getSession } from "@/lib/auth";
import { notFound } from "next/navigation";

export default async function EventRegistrationPage({ params }: { params: { id: string } }) {
    const session = await getSession();

    // Handle async params (Next.js 15)
    const resolvedParams = await Promise.resolve(params);
    const eventId = parseInt(resolvedParams.id);

    if (isNaN(eventId)) {
        notFound();
    }

    // Fetch specific event
    const event = await getEvent(eventId);

    if (!event) {
        notFound();
    }

    // Fetch data scoped to this event
    const tickets = await getAvailableTickets(event.id);
    const currentRegistration = await getUserRegistration(event.id);

    // Fetch questions
    let questions: any[] = [];
    if (event.registration_form_id) {
        questions = await getQuestions(event.registration_form_id);
    }

    return (
        <div className="container mx-auto max-w-5xl py-8">
            {/* Back Button */}
            <div className="mb-6">
                <a href="/register-conference" className="inline-flex items-center text-sm text-slate-500 hover:text-blue-600">
                    ← Back to Events
                </a>
            </div>

            <div className="mb-8 text-center">
                <h1 className="text-4xl font-bold text-slate-900 mb-2">{event.name_en}</h1>
                <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                    {event.description || "Secure your spot today by selecting a ticket below."}
                </p>
                <div className="mt-4 flex justify-center gap-6 text-sm text-slate-500">
                    <span>{event.start_date ? new Date(event.start_date).toLocaleDateString() : 'Date TBD'}</span>
                    <span>•</span>
                    <span>{event.venue_name || 'Venue TBD'}</span>
                </div>
            </div>

            <UserRegistrationForm
                tickets={tickets}
                currentRegistration={currentRegistration}
                questions={questions}
                eventId={event.id}
                user={session?.user ? {
                    first_name: (session.user.name || '').split(' ')[0] || '',
                    last_name: (session.user.name || '').split(' ').slice(1).join(' ') || '',
                    email: session.user.email || ''
                } : undefined}
            />
        </div>
    );
}
