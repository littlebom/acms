import { getDashboardStats } from "@/app/actions/dashboard";
import { AdminPageHeader, AdminPageContainer } from "@/components/admin/admin-page-header";
import { StatsCard } from "@/components/admin/dashboard/stats-card";
import { OverviewChart } from "@/components/admin/dashboard/overview-chart";
import { PaperStatusChart } from "@/components/admin/dashboard/paper-status-chart";
import { RecentActivity } from "@/components/admin/dashboard/recent-activity";
import { Users, FileText, CreditCard, Calendar, Activity } from "lucide-react";

export default async function AdminDashboardPage() {
    const stats = await getDashboardStats();

    if (!stats) {
        return (
            <AdminPageContainer>
                <div className="p-8 text-center text-red-500">
                    Failed to load dashboard data. Please try again later.
                </div>
            </AdminPageContainer>
        )
    }

    const { counts, trend, paperStatus, recentLogs } = stats;

    return (
        <AdminPageContainer>
            <AdminPageHeader
                title="Dashboard"
                description="Welcome back, Admin. Here's what's happening today."
            />

            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <StatsCard
                    title="Total Revenue"
                    value={`฿${counts.revenue.toLocaleString()}`}
                    icon={CreditCard}
                    iconClassName="text-green-600"
                    iconBgClassName="bg-green-100"
                    description="From paid registrations"
                />
                <StatsCard
                    title="Paid Registrations"
                    value={counts.registrations}
                    icon={Users}
                    iconClassName="text-blue-600"
                    iconBgClassName="bg-blue-100"
                    description="Confirmed attendees"
                />
                <StatsCard
                    title="Papers Submitted"
                    value={counts.papers}
                    icon={FileText}
                    iconClassName="text-purple-600"
                    iconBgClassName="bg-purple-100"
                    description="Across all tracks"
                />
                <StatsCard
                    title="Total Users"
                    value={counts.users}
                    icon={Users}
                    iconClassName="text-orange-600"
                    iconBgClassName="bg-orange-100"
                    description="Registered accounts"
                />
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                <OverviewChart data={trend} />
                <PaperStatusChart data={paperStatus} />
            </div>

            {/* Recent Activity & Quick Links (Optional, here just Activity) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <RecentActivity logs={recentLogs} />
            </div>

        </AdminPageContainer>
    );
}
