'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Edit2, Loader2, CheckCircle2, Clock } from "lucide-react";
import { createReviewer, updateReviewer } from "@/app/actions/paper-reviews";
import type { Reviewer } from "@/app/actions/paper-reviews";

interface ReviewersTableProps {
    reviewers: Reviewer[];
    availableUsers: { id: number; first_name: string; last_name: string; email: string }[];
}

export function ReviewersTable({ reviewers, availableUsers }: ReviewersTableProps) {
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [dialogOpen, setDialogOpen] = useState(false);
    const [editingReviewer, setEditingReviewer] = useState<Reviewer | null>(null);
    const [selectedUserId, setSelectedUserId] = useState<string>('');

    const handleCreate = async (formData: FormData) => {
        if (!selectedUserId) return;
        formData.set('user_id', selectedUserId);

        setLoading(true);
        const result = await createReviewer(formData);
        setLoading(false);

        if (result.error) {
            alert(result.error);
        } else {
            setDialogOpen(false);
            setSelectedUserId('');
            router.refresh();
        }
    };

    const handleUpdate = async (formData: FormData) => {
        setLoading(true);
        await updateReviewer(formData);
        setLoading(false);
        setEditingReviewer(null);
        router.refresh();
    };

    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between border-b">
                <div>
                    <CardTitle>All Reviewers</CardTitle>
                    <p className="text-sm text-slate-500 mt-1">
                        {reviewers.length} reviewer(s) registered
                    </p>
                </div>
                {availableUsers.length > 0 && (
                    <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                        <DialogTrigger asChild>
                            <Button size="sm">
                                <Plus className="h-4 w-4 mr-1" />
                                Add Reviewer
                            </Button>
                        </DialogTrigger>
                        <DialogContent>
                            <form action={handleCreate}>
                                <DialogHeader>
                                    <DialogTitle>Add New Reviewer</DialogTitle>
                                    <DialogDescription>
                                        Register a user as a paper reviewer
                                    </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4 py-4">
                                    <div className="space-y-2">
                                        <Label>Select User *</Label>
                                        <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Choose a user..." />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {availableUsers.map(user => (
                                                    <SelectItem key={user.id} value={user.id.toString()}>
                                                        {user.first_name} {user.last_name} ({user.email})
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="expertise">Expertise</Label>
                                        <Textarea
                                            id="expertise"
                                            name="expertise"
                                            placeholder="e.g., Machine Learning, Natural Language Processing"
                                            rows={2}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="affiliation">Affiliation</Label>
                                        <Input
                                            id="affiliation"
                                            name="affiliation"
                                            placeholder="University or Organization"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="bio">Bio</Label>
                                        <Textarea
                                            id="bio"
                                            name="bio"
                                            placeholder="Brief biography"
                                            rows={3}
                                        />
                                    </div>
                                </div>
                                <DialogFooter>
                                    <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                                        Cancel
                                    </Button>
                                    <Button type="submit" disabled={loading || !selectedUserId}>
                                        {loading && <Loader2 className="h-4 w-4 animate-spin mr-1" />}
                                        Add Reviewer
                                    </Button>
                                </DialogFooter>
                            </form>
                        </DialogContent>
                    </Dialog>
                )}
            </CardHeader>
            <CardContent className="p-0">
                <Table>
                    <TableHeader>
                        <TableRow className="bg-slate-50/50">
                            <TableHead>Reviewer</TableHead>
                            <TableHead>Expertise</TableHead>
                            <TableHead>Affiliation</TableHead>
                            <TableHead className="text-center">Assignments</TableHead>
                            <TableHead className="text-center">Completed</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {reviewers.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={7} className="h-24 text-center text-slate-500">
                                    No reviewers found. Add your first reviewer.
                                </TableCell>
                            </TableRow>
                        ) : (
                            reviewers.map((reviewer) => (
                                <TableRow key={reviewer.id}>
                                    <TableCell>
                                        <div>
                                            <p className="font-medium">
                                                {reviewer.first_name} {reviewer.last_name}
                                            </p>
                                            <p className="text-sm text-slate-500">{reviewer.email}</p>
                                        </div>
                                    </TableCell>
                                    <TableCell className="max-w-[200px]">
                                        <p className="text-sm text-slate-600 line-clamp-2">
                                            {reviewer.expertise || '-'}
                                        </p>
                                    </TableCell>
                                    <TableCell className="text-sm text-slate-600">
                                        {reviewer.affiliation || '-'}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        <Badge variant="outline">
                                            {reviewer.total_assignments}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-center">
                                        <Badge className="bg-emerald-100 text-emerald-700">
                                            {reviewer.completed_reviews}
                                        </Badge>
                                    </TableCell>
                                    <TableCell>
                                        {reviewer.is_active ? (
                                            <Badge className="bg-emerald-100 text-emerald-700">
                                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                                Active
                                            </Badge>
                                        ) : (
                                            <Badge variant="secondary">
                                                Inactive
                                            </Badge>
                                        )}
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => setEditingReviewer(reviewer)}
                                        >
                                            <Edit2 className="h-4 w-4" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </CardContent>

            {/* Edit Dialog */}
            <Dialog open={!!editingReviewer} onOpenChange={(open) => !open && setEditingReviewer(null)}>
                <DialogContent>
                    {editingReviewer && (
                        <form action={handleUpdate}>
                            <input type="hidden" name="id" value={editingReviewer.id} />
                            <DialogHeader>
                                <DialogTitle>Edit Reviewer</DialogTitle>
                                <DialogDescription>
                                    {editingReviewer.first_name} {editingReviewer.last_name}
                                </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4 py-4">
                                <div className="space-y-2">
                                    <Label htmlFor="edit_expertise">Expertise</Label>
                                    <Textarea
                                        id="edit_expertise"
                                        name="expertise"
                                        rows={2}
                                        defaultValue={editingReviewer.expertise || ''}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="edit_affiliation">Affiliation</Label>
                                    <Input
                                        id="edit_affiliation"
                                        name="affiliation"
                                        defaultValue={editingReviewer.affiliation || ''}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="edit_bio">Bio</Label>
                                    <Textarea
                                        id="edit_bio"
                                        name="bio"
                                        rows={3}
                                        defaultValue={editingReviewer.bio || ''}
                                    />
                                </div>
                                <div className="flex items-center space-x-2">
                                    <Switch
                                        id="edit_is_active"
                                        name="is_active"
                                        defaultChecked={editingReviewer.is_active}
                                        value="true"
                                    />
                                    <Label htmlFor="edit_is_active">Active</Label>
                                </div>
                            </div>
                            <DialogFooter>
                                <Button type="button" variant="outline" onClick={() => setEditingReviewer(null)}>
                                    Cancel
                                </Button>
                                <Button type="submit" disabled={loading}>
                                    {loading && <Loader2 className="h-4 w-4 animate-spin mr-1" />}
                                    Save Changes
                                </Button>
                            </DialogFooter>
                        </form>
                    )}
                </DialogContent>
            </Dialog>
        </Card>
    );
}
