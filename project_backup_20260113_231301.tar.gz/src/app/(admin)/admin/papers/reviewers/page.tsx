import { getReviewers } from "@/app/actions/paper-reviews";
import { ReviewersTable } from "./reviewers-table";
import { query } from "@/lib/db";
import { AdminPageHeader, AdminPageContainer } from "@/components/admin/admin-page-header";

// Get users who are not yet reviewers
async function getNonReviewerUsers() {
    const users = await query(`
        SELECT u.id, u.first_name, u.last_name, u.email
        FROM users u
        LEFT JOIN reviewers r ON u.id = r.user_id
        WHERE r.id IS NULL AND u.role IN ('admin', 'user')
        ORDER BY u.first_name ASC
    `) as any[];
    return users;
}

export default async function AdminReviewersPage() {
    const [reviewers, availableUsers] = await Promise.all([
        getReviewers(false),
        getNonReviewerUsers()
    ]);

    return (
        <AdminPageContainer>
            <AdminPageHeader
                title="Reviewers"
                description="Manage paper reviewers and their expertise"
            />
            <ReviewersTable reviewers={reviewers} availableUsers={availableUsers} />
        </AdminPageContainer>
    );
}
