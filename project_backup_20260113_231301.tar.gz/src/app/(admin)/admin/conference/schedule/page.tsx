import { getSchedules, getSchedule, getSessions, getScheduleAvailableSpeakers } from "@/app/actions/schedule";
import { getEvents } from "@/app/actions/events";
import { ScheduleList } from "@/components/admin/schedule-list";
import { AdminPageHeader, AdminPageContainer } from "@/components/admin/admin-page-header";
import { ScheduleEditor } from "@/components/admin/schedule-editor";

export const dynamic = 'force-dynamic';

export default async function SchedulePage() {
    // Mockup Logic: Try to find the "TCU International e-learning Conference" schedule
    const schedules = await getSchedules();
    const mockEventName = 'TCU International e-learning Conference';

    // Find schedule linked to this event
    const mockSchedule = schedules.find(s => s.event_title?.includes(mockEventName) || s.title.includes(mockEventName));

    if (mockSchedule) {
        // If found, show the detailed view directly (Mockup Request)
        const fullSchedule = await getSchedule(mockSchedule.id);
        const sessions = await getSessions(mockSchedule.id);
        const availableSpeakers = await getScheduleAvailableSpeakers(mockSchedule.id);

        if (fullSchedule) {
            return (
                <AdminPageContainer>
                    {/* Reuse Header but maybe simplified or part of Editor */}
                    <ScheduleEditor
                        schedule={fullSchedule}
                        sessions={sessions}
                        allSpeakers={availableSpeakers}
                    />
                </AdminPageContainer>
            );
        }
    }

    // Fallback to original list view
    const events = await getEvents();

    return (
        <AdminPageContainer>
            <AdminPageHeader
                title="Schedule Management"
                description="Manage schedules for your events."
            />
            <ScheduleList schedules={schedules} events={events} />
        </AdminPageContainer>
    );
}
