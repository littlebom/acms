'use client';

import { AdminSidebar } from "@/components/admin-sidebar";
import { usePathname } from "next/navigation";

export default function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const pathname = usePathname();
    const isCheckInPage = pathname === '/admin/conference/check-in';
    const isBuilderPage = pathname?.startsWith('/admin/website/builder');
    const isLayoutEditor = pathname?.startsWith('/admin/website/layout/header') || pathname?.startsWith('/admin/website/layout/footer');
    const isFullScreenPage = isCheckInPage || isBuilderPage || isLayoutEditor;

    return (
        <div className="flex min-h-screen bg-slate-100">
            {!isFullScreenPage && <AdminSidebar />}
            <main className={`flex-1 overflow-y-auto h-screen ${isFullScreenPage ? 'p-0' : 'p-8'}`}>
                {children}
            </main>
        </div>
    );
}

