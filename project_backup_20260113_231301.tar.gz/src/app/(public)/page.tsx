import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Users, ArrowRight } from "lucide-react";

export default function HomePage() {
    return (
        <div className="flex flex-col">
            {/* Hero Section */}
            <section className="relative py-20 md:py-32 bg-gradient-to-br from-[#2D4391] via-[#1e2e6e] to-slate-900 text-white overflow-hidden">
                <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10"></div>
                <div className="container mx-auto px-4 relative z-10 text-center">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-sm font-medium mb-6">
                        <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#4FDB90] opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#4FDB90]"></span>
                        </span>
                        Registration is now open!
                    </div>

                    <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-300">
                        ACMS 2025: <br className="hidden md:block" />
                        Future of Technology
                    </h1>

                    <p className="text-lg md:text-xl text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed">
                        Join leading researchers, innovators, and industry experts for a transformative conference experience. Explore the latest breakthroughs in AI, Software Engineering, and more.
                    </p>

                    <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                        <Link href="/register">
                            <Button size="lg" className="h-12 px-8 text-base bg-white text-[#2D4391] hover:bg-slate-100">
                                Register Now
                            </Button>
                        </Link>
                        <Link href="/schedule">
                            <Button size="lg" className="h-12 px-8 text-base bg-[#4fdb90] text-white hover:bg-[#4fdb90]/90">
                                View Schedule
                            </Button>
                        </Link>
                    </div>
                </div>
            </section>

            {/* Info Stats */}
            <section className="py-12 bg-white border-b">
                <div className="container mx-auto px-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                            <div className="p-3 rounded-xl bg-indigo-100 text-[#2D4391]">
                                <Calendar className="w-6 h-6" />
                            </div>
                            <div>
                                <p className="text-sm text-slate-500 font-medium">Date</p>
                                <p className="text-lg font-bold text-slate-900">Nov 24-26, 2025</p>
                            </div>
                        </div>

                        <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                            <div className="p-3 rounded-xl bg-purple-100 text-purple-600">
                                <MapPin className="w-6 h-6" />
                            </div>
                            <div>
                                <p className="text-sm text-slate-500 font-medium">Location</p>
                                <p className="text-lg font-bold text-slate-900">Bangkok Convention Center</p>
                            </div>
                        </div>

                        <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                            <div className="p-3 rounded-xl bg-blue-100 text-blue-600">
                                <Users className="w-6 h-6" />
                            </div>
                            <div>
                                <p className="text-sm text-slate-500 font-medium">Expected Attendees</p>
                                <p className="text-lg font-bold text-slate-900">500+ Participants</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* About Preview */}
            <section className="py-20">
                <div className="container mx-auto px-4">
                    <div className="flex flex-col md:flex-row items-center gap-12">
                        <div className="flex-1">
                            <h2 className="text-3xl font-bold mb-6 text-slate-900">Why Attend ACMS 2025?</h2>
                            <p className="text-slate-600 mb-6 leading-relaxed">
                                ACMS 2025 brings together the brightest minds in technology. Whether you are a researcher looking to present your work, a student eager to learn, or a professional seeking networking opportunities, this conference has something for you.
                            </p>
                            <ul className="space-y-4 mb-8">
                                {[
                                    "World-class Keynote Speakers",
                                    "Interactive Workshops & Tutorials",
                                    "Networking with Industry Leaders",
                                    "Publication Opportunities"
                                ].map((item, i) => (
                                    <li key={i} className="flex items-center gap-3 text-slate-700">
                                        <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center text-[#4FDB90]">
                                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                                        </div>
                                        {item}
                                    </li>
                                ))}
                            </ul>
                            <Link href="/about">
                                <Button variant="link" className="p-0 h-auto text-[#2D4391] font-semibold group">
                                    Learn more about the event
                                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                                </Button>
                            </Link>
                        </div>
                        <div className="flex-1 relative">
                            <div className="aspect-video rounded-2xl bg-slate-200 overflow-hidden shadow-2xl">
                                {/* Placeholder for Event Image */}
                                <div className="w-full h-full bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center text-slate-400">
                                    Event Image
                                </div>
                            </div>
                            <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-dots-pattern opacity-20"></div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}
