'use server';

import { query } from '@/lib/db';

export async function getDashboardStats() {
    try {
        // 1. Basic Counts
        const [
            usersCount,
            papersCount,
            registrationsCount
        ] = await Promise.all([
            query('SELECT COUNT(*) as count FROM users'),
            query('SELECT COUNT(*) as count FROM papers'),
            query('SELECT COUNT(*) as count FROM registrations WHERE status = "paid"') // Count paid registrations
        ]);

        // 2. Total Revenue (Join registrations and tickets)
        const revenueResult = await query(`
            SELECT SUM(t.price) as total
            FROM registrations r
            JOIN tickets t ON r.ticket_id = t.id
            WHERE r.status = 'paid'
        `) as any[];
        const totalRevenue = revenueResult[0]?.total || 0;

        // 3. Registration Trend (Last 30 Days)
        const trendResult = await query(`
            SELECT DATE(registered_at) as date, COUNT(*) as count
            FROM registrations
            WHERE registered_at >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
            GROUP BY DATE(registered_at)
            ORDER BY date ASC
        `) as any[];

        // Fill in missing days for a smooth chart
        const trend = fillMissingDates(trendResult, 30);

        // 4. Paper Status Distribution
        const paperStatusResult = await query(`
            SELECT status, COUNT(*) as count
            FROM papers
            GROUP BY status
        `) as any[];

        // 5. Recent Activity (Audit Logs)
        const recentLogsResult = await query(`
            SELECT al.id, al.action, al.resource, al.details, al.created_at, u.first_name, u.email
            FROM audit_logs al
            LEFT JOIN users u ON al.user_id = u.id
            ORDER BY al.created_at DESC
            LIMIT 5
        `) as any[];

        const recentLogs = recentLogsResult.map(log => ({
            id: log.id,
            user: log.first_name || log.email || 'Unknown',
            action: log.action,
            details: log.details,
            time: log.created_at
        }));

        return {
            counts: {
                users: (usersCount as any[])[0].count,
                papers: (papersCount as any[])[0].count,
                registrations: (registrationsCount as any[])[0].count,
                revenue: totalRevenue
            },
            trend,
            paperStatus: paperStatusResult,
            recentLogs
        };

    } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        return null;
    }
}

function fillMissingDates(data: any[], days: number) {
    const result = [];
    const today = new Date();
    const dataMap = new Map(data.map(item => {
        // Ensure item.date is a string 'YYYY-MM-DD'
        const dateStr = item.date instanceof Date ? item.date.toISOString().split('T')[0] : item.date;
        return [dateStr, item.count];
    }));

    for (let i = days - 1; i >= 0; i--) {
        const d = new Date();
        d.setDate(today.getDate() - i);
        const dateStr = d.toISOString().split('T')[0];
        result.push({
            date: dateStr,
            count: dataMap.get(dateStr) || 0
        });
    }
    return result;
}
