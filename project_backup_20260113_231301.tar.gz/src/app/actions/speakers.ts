'use server';

import { revalidatePath } from 'next/cache';
import { query } from '@/lib/db';
import { writeFile } from 'fs/promises';
import { join } from 'path';
import bcrypt from 'bcryptjs';

export interface SpeakerGroup {
    id: number;
    name: string;
    description: string | null;
    event_id: number | null;
    event_title?: string;
    member_count?: number;
}

export interface SpeakerGroupMember {
    group_id: number;
    user_id: number;
    first_name: string;
    last_name: string;
    email: string;
    profile_image: string | null;
    bio?: string; // Added bio
}

// --- Speaker Groups ---

export async function getSpeakerGroups() {
    const groups = await query(`
        SELECT sg.*, e.name_en as event_title, COUNT(sgm.user_id) as member_count 
        FROM speaker_groups sg
        LEFT JOIN events e ON sg.event_id = e.id
        LEFT JOIN speaker_group_members sgm ON sg.id = sgm.group_id
        GROUP BY sg.id
        ORDER BY sg.id DESC
    `) as SpeakerGroup[];
    return groups;
}

export async function getSpeakerGroup(id: number) {
    const groups = await query(`
        SELECT sg.*, e.name_en as event_title 
        FROM speaker_groups sg
        LEFT JOIN events e ON sg.event_id = e.id
        WHERE sg.id = ?
    `, [id]) as SpeakerGroup[];
    return groups.length > 0 ? groups[0] : null;
}

export async function createSpeakerGroup(formData: FormData) {
    const eventId = parseInt(formData.get('event_id') as string);

    // Fetch event name to generate group name
    const events = await query('SELECT name_en FROM events WHERE id = ?', [eventId]) as { name_en: string }[];
    if (events.length === 0) {
        return { error: 'Event not found' };
    }

    const eventTitle = events[0].name_en;
    const name = `${eventTitle} Speakers`;
    const description = `Official speaker group for ${eventTitle}`;

    try {
        // 1. Create Group
        const result = await query(
            'INSERT INTO speaker_groups (title, description, event_id) VALUES (?, ?, ?)',
            [name, description, eventId]
        ) as any;

        const groupId = result.insertId;

        // 2. Link Event to Group
        await query('UPDATE events SET speaker_group_id = ? WHERE id = ?', [groupId, eventId]);

        revalidatePath('/admin/speakers');
        return { success: true };
    } catch (error) {
        console.error('Create speaker group error:', error);
        return { error: 'Failed to create speaker group' };
    }
}

export async function deleteSpeakerGroup(id: number) {
    try {
        // Unlink from event first
        await query('UPDATE events SET speaker_group_id = NULL WHERE speaker_group_id = ?', [id]);
        await query('DELETE FROM speaker_groups WHERE id = ?', [id]);
        revalidatePath('/admin/speakers');
        return { success: true };
    } catch (error) {
        console.error('Delete speaker group error:', error);
        return { error: 'Failed to delete speaker group' };
    }
}

// --- Members ---

export async function getGroupMembers(groupId: number) {
    const members = await query(`
        SELECT sgm.group_id, u.id as user_id, u.first_name, u.last_name, u.email, u.profile_image, u.bio
        FROM speaker_group_members sgm
        JOIN users u ON sgm.user_id = u.id
        WHERE sgm.group_id = ?
    `, [groupId]) as SpeakerGroupMember[];
    return members;
}

export async function addGroupMember(groupId: number, userId: number) {
    try {
        await query(
            'INSERT INTO speaker_group_members (group_id, user_id) VALUES (?, ?)',
            [groupId, userId]
        );
        revalidatePath(`/admin/speakers/${groupId}`);
        return { success: true };
    } catch (error) {
        console.error('Add group member error:', error);
        return { error: 'Failed to add member' };
    }
}

export async function removeGroupMember(groupId: number, userId: number) {
    try {
        await query(
            'DELETE FROM speaker_group_members WHERE group_id = ? AND user_id = ?',
            [groupId, userId]
        );
        revalidatePath(`/admin/speakers/${groupId}`);
        return { success: true };
    } catch (error) {
        console.error('Remove group member error:', error);
        return { error: 'Failed to remove member' };
    }
}

// Fetch all users to be selected as speakers
export async function getSpeakers() {
    const users = await query('SELECT id, first_name, last_name, email, profile_image FROM users ORDER BY first_name ASC') as any[];
    return users;
}

// --- Update Speaker Details ---

export async function updateSpeakerDetails(formData: FormData) {
    const userId = parseInt(formData.get('user_id') as string);
    const groupId = formData.get('group_id'); // For revalidation
    const firstName = formData.get('first_name') as string;
    const lastName = formData.get('last_name') as string;
    const email = formData.get('email') as string;
    const bio = formData.get('bio') as string;
    const imageFile = formData.get('profile_image') as File;

    try {
        let imageUrl = null;

        // Handle Image Upload
        if (imageFile && imageFile.size > 0) {
            const bytes = await imageFile.arrayBuffer();
            const buffer = Buffer.from(bytes);
            const fileName = `speaker-${userId}-${Date.now()}-${imageFile.name}`;
            const path = join(process.cwd(), 'public/uploads', fileName);

            await writeFile(path, buffer);
            imageUrl = `/uploads/${fileName}`;
        }

        // Build Update Query
        let sql = 'UPDATE users SET first_name = ?, last_name = ?, email = ?, bio = ?';
        const params: any[] = [firstName, lastName, email, bio];

        if (imageUrl) {
            sql += ', profile_image = ?';
            params.push(imageUrl);
        }

        sql += ' WHERE id = ?';
        params.push(userId);

        await query(sql, params);

        if (groupId) {
            revalidatePath(`/admin/speakers/${groupId}`);
        }
        return { success: true };
    } catch (error) {
        console.error('Update speaker details error:', error);
        return { error: 'Failed to update speaker details' };
    }
}

// --- Create New Speaker (User) ---

export async function createSpeakerUser(formData: FormData) {
    const groupId = parseInt(formData.get('group_id') as string);
    const firstName = formData.get('first_name') as string;
    const lastName = formData.get('last_name') as string;
    const email = formData.get('email') as string;
    const password = formData.get('password') as string; // Optional, default if empty
    const bio = formData.get('bio') as string;
    const imageFile = formData.get('profile_image') as File;

    try {
        // 1. Check if email exists
        const existing = await query('SELECT id FROM users WHERE email = ?', [email]) as { id: number }[];
        if (existing.length > 0) {
            return { error: 'Email already exists' };
        }

        // 2. Hash Password
        const passwordToHash = password || 'Speaker123!'; // Default password
        const hashedPassword = await bcrypt.hash(passwordToHash, 10);

        // 3. Handle Image Upload
        let imageUrl = null;
        if (imageFile && imageFile.size > 0) {
            const bytes = await imageFile.arrayBuffer();
            const buffer = Buffer.from(bytes);
            const fileName = `speaker-new-${Date.now()}-${imageFile.name}`;
            const path = join(process.cwd(), 'public/uploads', fileName);

            await writeFile(path, buffer);
            imageUrl = `/uploads/${fileName}`;
        }

        // 4. Create User
        const result = await query(
            `INSERT INTO users (first_name, last_name, email, password_hash, role, bio, profile_image) 
             VALUES (?, ?, ?, ?, 'attendee', ?, ?)`,
            [firstName, lastName, email, hashedPassword, bio, imageUrl]
        ) as any;

        const userId = result.insertId;

        // 5. Add to Group
        await addGroupMember(groupId, userId);

        revalidatePath(`/admin/speakers/${groupId}`);
        return { success: true };
    } catch (error) {
        console.error('Create speaker user error:', error);
        return { error: 'Failed to create speaker' };
    }
}
