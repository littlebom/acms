'use server';

import { revalidatePath } from 'next/cache';
import { query } from '@/lib/db';

export interface EventData {
    id: number;
    title: string; // Alias for name_en for frontend compatibility
    name_en: string;
    name_th: string | null;
    description: string | null;
    venue_name: string | null;
    venue_map_url: string | null;
    start_date: Date | null;
    end_date: Date | null;
    submission_deadline: Date | null;
    registration_deadline: Date | null;
    registration_form_id: number | null;
    speaker_group_id: number | null;
    schedule_id: number | null;
    is_active: boolean;
}

// Get all events for the list
export async function getEvents() {
    const events = await query('SELECT *, name_en as title FROM events ORDER BY start_date DESC') as EventData[];
    return events;
}

// Get all events available for registration (future events)
export async function getAvailableEvents() {
    return await query(`
        SELECT *, name_en as title 
        FROM events 
        WHERE (registration_deadline IS NULL OR registration_deadline >= CURDATE())
        AND (end_date IS NULL OR end_date >= CURDATE())
        ORDER BY start_date ASC
    `) as EventData[];
}

// Get a single event (by ID or the active one)
export async function getEvent(id?: number) {
    let sql = 'SELECT *, name_en as title FROM events';
    const params: any[] = [];

    if (id) {
        sql += ' WHERE id = ?';
        params.push(id);
    } else {
        // If no ID, get the active event
        sql += ' WHERE is_active = TRUE LIMIT 1';
    }

    const events = await query(sql, params) as EventData[];

    // Fallback: If no active event found, return the latest one
    if (!id && events.length === 0) {
        const latest = await query('SELECT *, name_en as title FROM events ORDER BY id DESC LIMIT 1') as EventData[];
        return latest.length > 0 ? latest[0] : null;
    }

    return events.length > 0 ? events[0] : null;
}

export async function createEvent(formData: FormData) {
    const name_en = formData.get('name_en') as string;
    const name_th = formData.get('name_th') as string;
    const description = formData.get('description') as string;
    const venue_name = formData.get('venue_name') as string;
    const venue_map_url = formData.get('venue_map_url') as string;

    const parseId = (key: string) => {
        const val = formData.get(key);
        return val && val !== 'none' ? parseInt(val as string) : null;
    };

    const registration_form_id = parseId('registration_form_id');
    const speaker_group_id = parseId('speaker_group_id');
    const schedule_id = parseId('schedule_id');

    const parseDate = (val: FormDataEntryValue | null) => val ? new Date(val as string) : null;

    const start_date = parseDate(formData.get('start_date'));
    const end_date = parseDate(formData.get('end_date'));
    const submission_deadline = parseDate(formData.get('submission_deadline'));
    const registration_deadline = parseDate(formData.get('registration_deadline'));

    try {
        await query(
            `INSERT INTO events (
                name_en, name_th, description, 
                venue_name, venue_map_url,
                start_date, end_date,
                submission_deadline, registration_deadline,
                registration_form_id, speaker_group_id, schedule_id,
                is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, FALSE)`,
            [
                name_en, name_th, description,
                venue_name, venue_map_url,
                start_date, end_date,
                submission_deadline, registration_deadline,
                registration_form_id, speaker_group_id, schedule_id
            ]
        );
        revalidatePath('/admin/conference/events');
        return { success: true };
    } catch (error) {
        console.error('Create event error:', error);
        return { error: 'Failed to create event' };
    }
}

export async function updateEvent(formData: FormData) {
    const id = formData.get('id');
    const name_en = formData.get('name_en') as string;
    const name_th = formData.get('name_th') as string;
    const description = formData.get('description') as string;
    const venue_name = formData.get('venue_name') as string;
    const venue_map_url = formData.get('venue_map_url') as string;

    const parseId = (key: string) => {
        const val = formData.get(key);
        if (!val || val === 'none') return null;
        const parsed = parseInt(val as string);
        return isNaN(parsed) ? null : parsed;
    };

    const registration_form_id = parseId('registration_form_id');
    const speaker_group_id = parseId('speaker_group_id');
    const schedule_id = parseId('schedule_id');

    // Debug logging
    console.log('Update Event Data:', {
        id,
        registration_form_id,
        speaker_group_id,
        schedule_id,
        regs_raw: formData.get('registration_form_id')
    });

    const parseDate = (val: FormDataEntryValue | null) => val ? new Date(val as string) : null;

    const start_date = parseDate(formData.get('start_date'));
    const end_date = parseDate(formData.get('end_date'));
    const submission_deadline = parseDate(formData.get('submission_deadline'));
    const registration_deadline = parseDate(formData.get('registration_deadline'));

    try {
        await query(
            `UPDATE events SET 
                name_en = ?, name_th = ?, description = ?, 
                venue_name = ?, venue_map_url = ?,
                start_date = ?, end_date = ?,
                submission_deadline = ?, registration_deadline = ?,
                registration_form_id = ?, speaker_group_id = ?, schedule_id = ?
                WHERE id = ?`,
            [
                name_en, name_th, description,
                venue_name, venue_map_url,
                start_date, end_date,
                submission_deadline, registration_deadline,
                registration_form_id, speaker_group_id, schedule_id,
                id
            ]
        );

        revalidatePath('/admin/conference/events');
        revalidatePath(`/admin/conference/events/${id}`);
        return { success: true };
    } catch (error) {
        console.error('Update event error:', error);
        const fs = require('fs');
        fs.writeFileSync('update_error.log', `Error: ${JSON.stringify(error, Object.getOwnPropertyNames(error))}\n`);
        return { error: 'Failed to update event' };
    }
}

export async function activateEvent(id: number) {
    try {
        // Deactivate all first
        await query('UPDATE events SET is_active = FALSE');
        // Activate the selected one
        await query('UPDATE events SET is_active = TRUE WHERE id = ?', [id]);

        revalidatePath('/admin/conference/events');
        return { success: true };
    } catch (error) {
        console.error('Activate event error:', error);
        return { error: 'Failed to activate event' };
    }
}

export async function deleteEvent(id: number) {
    try {
        // 1. Delete related Tickets
        await query('DELETE FROM tickets WHERE event_id = ?', [id]);

        // 2. Delete related Event Questions (and Answers via cascade if set, otherwise manual)
        // Check if answers need manual deletion
        await query('DELETE FROM answers WHERE event_id = ?', [id]);
        await query('DELETE FROM event_questions WHERE event_id = ?', [id]);

        // 3. Unlink/Delete Sessions (if they have event_id directly)
        await query('DELETE FROM sessions WHERE event_id = ?', [id]);

        // 4. Unlink Schedules and Speaker Groups (handled by ON DELETE SET NULL in DB, but good to be explicit or if we want to delete them)
        // For now, let's just unlink them to be safe, or let DB handle it.
        // If we want to DELETE the schedule associated with this event:
        // await query('DELETE FROM schedules WHERE event_id = ?', [id]); 
        // But maybe user wants to keep the schedule template? Let's stick to unlinking (DB does it).

        // 5. Finally Delete Event
        await query('DELETE FROM events WHERE id = ?', [id]);

        revalidatePath('/admin/conference/events');
        return { success: true };
    } catch (error) {
        console.error('Delete event error:', error);
        return { error: 'Failed to delete event. Please ensure all related data is removed.' };
    }
}

export async function getEventSpeakers(eventId: number) {
    try {
        // 1. Get Speaker Group ID
        const events = await query('SELECT speaker_group_id FROM events WHERE id = ?', [eventId]) as { speaker_group_id: number }[];

        if (events.length === 0 || !events[0].speaker_group_id) {
            return [];
        }

        const groupId = events[0].speaker_group_id;

        // 2. Get Members
        const speakers = await query(`
            SELECT u.id, u.first_name, u.last_name, u.email, u.profile_image, u.bio
            FROM speaker_group_members sgm
            JOIN users u ON sgm.user_id = u.id
            WHERE sgm.group_id = ?
            ORDER BY u.first_name ASC
        `, [groupId]) as any[];

        return speakers;
    } catch (error) {
        console.error('Get event speakers error:', error);
        return [];
    }
}
