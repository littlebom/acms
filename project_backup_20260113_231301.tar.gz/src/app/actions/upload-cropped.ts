'use server';

import { writeFile } from 'fs/promises';
import { join } from 'path';
import { revalidatePath } from 'next/cache';

const UPLOAD_DIR = 'uploads';
const PUBLIC_DIR = join(process.cwd(), 'public', UPLOAD_DIR);

/**
 * Upload a cropped image from base64 data
 */
export async function uploadCroppedImage(
    base64Data: string,
    originalFileName?: string
): Promise<{ success: boolean; error?: string; url?: string }> {
    try {
        // Remove data URL prefix if present
        const base64String = base64Data.replace(/^data:image\/\w+;base64,/, '');
        const buffer = Buffer.from(base64String, 'base64');

        // Create unique filename
        const timestamp = Date.now();
        const randomStr = Math.random().toString(36).substring(7);
        const fileName = `cropped-${timestamp}-${randomStr}.jpg`;
        const filePath = join(PUBLIC_DIR, fileName);

        // Write file
        await writeFile(filePath, buffer);

        revalidatePath('/admin/system/media');
        revalidatePath('/admin/conference/tickets');

        return {
            success: true,
            url: `/${UPLOAD_DIR}/${fileName}`
        };
    } catch (error) {
        console.error('Upload cropped image error:', error);
        return {
            success: false,
            error: 'Failed to upload cropped image'
        };
    }
}

/**
 * Convert Blob URL to base64
 */
export async function blobToBase64(blobUrl: string): Promise<string> {
    const response = await fetch(blobUrl);
    const blob = await response.blob();
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}
