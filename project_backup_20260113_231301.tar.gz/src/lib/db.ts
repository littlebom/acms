import mysql from 'mysql2/promise';

declare global {
    var mysqlPool: mysql.Pool | undefined;
}

export const pool = global.mysqlPool || mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'KKiabkob',
    database: process.env.DB_NAME || 'acms_db',
    waitForConnections: true,
    connectionLimit: 10,
    maxIdle: 10,
    idleTimeout: 60000,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
});

if (process.env.NODE_ENV !== 'production') global.mysqlPool = pool;

export async function query(sql: string, params?: any[]) {
    const [results] = await pool.execute(sql, params);
    return results;
}
