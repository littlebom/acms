-- MySQL dump 10.13  Distrib 9.5.0, for macos15.7 (arm64)
--
-- Host: localhost    Database: acms_db
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '134adc76-da23-11f0-889c-026d1b42f712:1-4557,
2e1b5858-c08f-11f0-90d3-ba299b910565:1-11110';

--
-- Table structure for table `answers`
--

DROP TABLE IF EXISTS `answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `answers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `questionnaire_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `question_id` int NOT NULL,
  `answer_text` text,
  `answer_value` int DEFAULT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `answers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `answers_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  CONSTRAINT `answers_ibfk_3` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answers`
--

LOCK TABLES `answers` WRITE;
/*!40000 ALTER TABLE `answers` DISABLE KEYS */;
INSERT INTO `answers` VALUES (1,8,NULL,7,2,'None',NULL,NULL,'2025-12-08 03:30:40'),(4,8,NULL,7,2,'ไม่แพ้',NULL,NULL,'2026-01-14 15:40:52'),(5,8,NULL,7,2,'แแแ',NULL,NULL,'2026-01-14 16:35:33'),(6,8,NULL,7,2,'ทานได้หมด',NULL,NULL,'2026-01-15 06:04:36');
/*!40000 ALTER TABLE `answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `action` varchar(50) NOT NULL,
  `resource` varchar(100) NOT NULL,
  `details` text,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'UPDATE','system_setting','{\"change\": \"Changed conference name\"}','127.0.0.1','2026-01-12 15:36:16');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image_url` varchar(500) NOT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_th` varchar(255) DEFAULT NULL,
  `subtitle_en` text,
  `subtitle_th` text,
  `button_text_en` varchar(100) DEFAULT NULL,
  `button_text_th` varchar(100) DEFAULT NULL,
  `button_link` varchar(500) DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_banners_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chatbot_faqs`
--

DROP TABLE IF EXISTS `chatbot_faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatbot_faqs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `question` (`question`,`answer`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatbot_faqs`
--

LOCK TABLES `chatbot_faqs` WRITE;
/*!40000 ALTER TABLE `chatbot_faqs` DISABLE KEYS */;
INSERT INTO `chatbot_faqs` VALUES (1,'deadline','The submission deadline for papers is June 30th, 2026.',1,'2026-01-12 15:41:18'),(2,'register','You can register for the conference by clicking the \"Register\" button in the top right corner.',1,'2026-01-12 15:41:18'),(3,'contact','You can contact us at support@acms-conference.com.',1,'2026-01-12 15:41:18'),(4,'location','The conference will be held at the Grand Hall, Bangkok.',1,'2026-01-12 15:41:18');
/*!40000 ALTER TABLE `chatbot_faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `variables` json DEFAULT NULL COMMENT 'Available variables like {{name}}, {{email}}',
  `category` enum('registration','paper','payment','reminder','announcement','custom') DEFAULT 'custom',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES (1,'welcome','Welcome to ACMS','Dear {{name}},\n\nWelcome to ACMS! Your account has been created successfully.\n\nBest regards,\nACMS Team','[\"name\", \"email\"]','registration',1,'2025-12-10 08:03:34','2025-12-10 08:03:34'),(2,'payment_confirmed','Payment Confirmed','Dear {{name}},\n\nYour payment has been confirmed. Thank you for registering!\n\nTicket: {{ticket_name}}\nAmount: {{amount}}\n\nBest regards,\nACMS Team','[\"name\", \"ticket_name\", \"amount\"]','payment',1,'2025-12-10 08:03:34','2025-12-10 08:03:34'),(3,'paper_submitted','Paper Submission Received','Dear {{name}},\n\nYour paper \"{{paper_title}}\" has been submitted successfully.\n\nPaper ID: {{paper_id}}\n\nBest regards,\nACMS Team','[\"name\", \"paper_title\", \"paper_id\"]','paper',1,'2025-12-10 08:03:34','2025-12-10 08:03:34'),(4,'announcement','Announcement from ACMS','Dear {{name}},\n\n{{message}}\n\nBest regards,\nACMS Team','[\"name\", \"message\"]','announcement',1,'2025-12-10 08:03:34','2025-12-10 08:03:34');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_questions`
--

DROP TABLE IF EXISTS `event_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_questions` (
  `event_id` int NOT NULL,
  `question_id` int NOT NULL,
  `display_order` int DEFAULT '0',
  PRIMARY KEY (`event_id`,`question_id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `event_questions_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `event_questions_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_questions`
--

LOCK TABLES `event_questions` WRITE;
/*!40000 ALTER TABLE `event_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_th` varchar(255) DEFAULT NULL,
  `short_description` text,
  `slug` varchar(255) NOT NULL,
  `description` text,
  `theme_color_primary` varchar(50) DEFAULT NULL,
  `theme_color_accent` varchar(50) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `venue_name` varchar(255) DEFAULT NULL,
  `venue_map_url` text,
  `address` text,
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `social_facebook` varchar(255) DEFAULT NULL,
  `social_line` varchar(100) DEFAULT NULL,
  `social_website` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `registration_start_date` datetime DEFAULT NULL,
  `submission_deadline` datetime DEFAULT NULL,
  `registration_deadline` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `registration_form_id` int DEFAULT NULL,
  `speaker_group_id` int DEFAULT NULL,
  `schedule_id` int DEFAULT NULL,
  `cover_image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_event_reg_form` (`registration_form_id`),
  KEY `fk_event_speaker_group` (`speaker_group_id`),
  KEY `fk_event_schedule` (`schedule_id`),
  CONSTRAINT `fk_event_reg_form` FOREIGN KEY (`registration_form_id`) REFERENCES `questionnaires` (`id`),
  CONSTRAINT `fk_event_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`),
  CONSTRAINT `fk_event_speaker_group` FOREIGN KEY (`speaker_group_id`) REFERENCES `speaker_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (7,'The 5th National Conference on Innovation and Information Technology: 2026','AI & The Next Frontier: Shaping a Sustainable Future','The 5th National Conference on Innovation and Information Technology (InnovateThai 2026)','event-7','<p style=\"text-align: justify;\">InnovateThai 2026 marks the fifth milestone of Thailand\'s premier academic gathering dedicated to information technology and innovation. Under the visionary theme \"AI &amp; The Next Frontier: Shaping a Sustainable Future,\" this conference aims to bridge the critical gap between cutting-edge theoretical research and practical industrial applications. It serves as a vital ecosystem where scholars, industry leaders, policymakers, and students converge to explore how emerging technologies can solve complex global challenges, driving the region towards a digital-first economy while prioritizing environmental sustainability.</p><p style=\"text-align: justify;\">The technical program is designed to be comprehensive and forward-looking, focusing heavily on transformative technologies such as Generative Artificial Intelligence, Quantum Computing, Blockchain, and Green Technology. Attendees will have access to a diverse range of peer-reviewed research papers and technical sessions that dive deep into the mechanics of these advancements. Beyond the trends, the conference emphasizes rigorous academic inquiry and data-driven results, providing a stage for researchers to present breakthroughs in algorithms, cybersecurity frameworks, and smart city infrastructure that will define the landscape of modern computer science for the next decade.</p><p style=\"text-align: justify;\">Beyond the lecture halls, InnovateThai 2026 offers an immersive experience designed to foster collaboration and professional growth. The event features hands-on workshops, interactive panel discussions regarding digital ethics, and an extensive innovation exhibition showcasing prototypes from both university labs and leading tech companies. Participants will have the unique opportunity to network with world-class keynote speakers and thought leaders, sparking cross-disciplinary partnerships that extend far beyond the three-day event. Whether you are an academic looking to publish or a developer seeking new tools, this conference provides the ultimate platform to connect and inspire.</p>',NULL,NULL,NULL,'Queen Sirikit National Convention Center (QSNCC)','https://www.google.com/maps/place/Queen+Sirikit+National+Convention+Center,+60+Ratchadaphisek+Rd,+Khwaeng+Khlong+Toei,+Khet+Khlong+Toei,+Krung+Thep+Maha+Nakhon+10110/@13.7246638,100.5583086,18.01z/data=!4m6!3m5!1s0x30e29f1a313429af:0x8e4a8b6860c32195!8m2!3d13.7243387!4d100.5586199!16s%2Fg%2F1yfdrlpxl?entry=ttu&g_ep=EgoyMDI2MDEwNy4wIKXMDSoASAFQAw%3D%3D','60 Queen Sirikit National Convention Center, Ratchadaphisek Road, Khlong Toei Sub-district, Khlong Toei District, Bangkok','0988721888','admin@acms.com','','','','2025-12-01','2026-02-02','2026-01-12 09:55:00',NULL,'2026-01-31 09:55:00',1,1,5,8,'/uploads/1768361834996-cover.jpg');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `menu_location` enum('header','footer','sidebar') DEFAULT 'header',
  `parent_id` int DEFAULT NULL,
  `title_en` varchar(100) NOT NULL,
  `title_th` varchar(100) DEFAULT NULL,
  `url` varchar(500) NOT NULL,
  `target` enum('_self','_blank') DEFAULT '_self',
  `icon` varchar(50) DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `idx_menu_items_location` (`menu_location`),
  CONSTRAINT `menu_items_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES (1,'header',NULL,'Home','หน้าแรก','/','_self',NULL,1,1,'2025-12-10 08:25:50'),(2,'header',NULL,'About','เกี่ยวกับ','/about','_self',NULL,2,1,'2025-12-10 08:25:50'),(3,'header',NULL,'Schedule','กำหนดการ','/schedule','_self',NULL,3,1,'2025-12-10 08:25:50'),(4,'header',NULL,'Speakers','วิทยากร','/speakers','_self',NULL,4,1,'2025-12-10 08:25:50'),(5,'header',NULL,'Contact','ติดต่อ','/contact','_self',NULL,5,1,'2025-12-10 08:25:50'),(6,'footer',NULL,'Privacy Policy','นโยบายความเป็นส่วนตัว','/privacy','_self',NULL,1,1,'2025-12-10 08:25:50'),(7,'footer',NULL,'Terms of Service','ข้อกำหนดการใช้งาน','/terms','_self',NULL,2,1,'2025-12-10 08:25:50');
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text,
  `image_url` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'Call for Papers: The Future of Education Technology','We are excited to announce that the Call for Papers for the 2026 International Conference on Education Technology is now open. We invite researchers, educators, and industry professionals to submit their latest work on innovative learning solutions, AI in education, and digital transformation in schools. The deadline for submission is March 31, 2026. Selected papers will be published in the conference proceedings and special issues of partner journals.','https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=800&auto=format&fit=crop&q=60',1,'2026-01-13 08:54:40','2026-01-13 08:54:40'),(2,'Keynote Speaker Announcement: Prof. Sarah Johnson','We are honored to confirm Professor Sarah Johnson from MIT as our lead keynote speaker. Dr. Johnson is a pioneer in adaptive learning systems and will be sharing her insights on \'The Role of AI in Personalized Learning\'. Her session is scheduled for the opening day of the conference and promises to be an inspiring start to our event.','https://images.unsplash.com/photo-1544531586-fde5298cdd40?w=800&auto=format&fit=crop&q=60',1,'2026-01-13 08:54:40','2026-01-13 08:54:40'),(3,'Early Bird Registration Ending Soon','Don\'t miss out on the discounted Early Bird rates! Registration closes on February 15, 2026. Secure your spot now to save up to 20% on the standard conference fee. The registration includes access to all sessions, workshops, networking events, and the gala dinner. Visit the Registration page to sign up today.','https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&auto=format&fit=crop&q=60',1,'2026-01-13 08:54:40','2026-01-13 08:54:40'),(4,'New Workshop Tracks Added','Based on popular demand, we have added two new workshop tracks to this year\'s program: \'Immersive Learning with VR/AR\' and \'Data Privacy in EdTech\'. These hands-on sessions will provide participants with practical skills and strategies to implement in their own institutions. Seats are limited, so be sure to register early for these specific tracks.','https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800&auto=format&fit=crop&q=60',1,'2026-01-13 08:54:40','2026-01-13 08:54:40');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('announcement','email','system','reminder') DEFAULT 'announcement',
  `target_type` enum('all','attendee','speaker','reviewer','author','admin','custom') DEFAULT 'all',
  `target_user_ids` json DEFAULT NULL COMMENT 'Specific user IDs if target_type is custom',
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `is_email` tinyint(1) DEFAULT '0' COMMENT 'Also send via email',
  `email_subject` varchar(255) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL COMMENT 'Schedule for future sending',
  `sent_at` datetime DEFAULT NULL,
  `status` enum('draft','scheduled','sending','sent','failed') DEFAULT 'draft',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_notifications_status` (`status`),
  KEY `idx_notifications_type` (`type`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `title_th` varchar(255) DEFAULT NULL,
  `content_en` longtext,
  `content_th` longtext,
  `excerpt_en` text,
  `excerpt_th` text,
  `featured_image` varchar(500) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text,
  `template` enum('default','full-width','sidebar','landing') DEFAULT 'default',
  `status` enum('draft','published','archived') DEFAULT 'draft',
  `publish_date` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `created_by` (`created_by`),
  KEY `idx_pages_slug` (`slug`),
  KEY `idx_pages_status` (`status`),
  CONSTRAINT `pages_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paper_authors`
--

DROP TABLE IF EXISTS `paper_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paper_authors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `paper_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `author_order` int DEFAULT '1',
  `is_corresponding` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `paper_id` (`paper_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `paper_authors_ibfk_1` FOREIGN KEY (`paper_id`) REFERENCES `papers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `paper_authors_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paper_authors`
--

LOCK TABLES `paper_authors` WRITE;
/*!40000 ALTER TABLE `paper_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `paper_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paper_decisions`
--

DROP TABLE IF EXISTS `paper_decisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paper_decisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `paper_id` int NOT NULL,
  `decided_by` int NOT NULL,
  `decision` enum('accept','minor_revision','major_revision','reject') NOT NULL,
  `comments` text,
  `internal_notes` text,
  `decided_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `paper_id` (`paper_id`),
  KEY `decided_by` (`decided_by`),
  CONSTRAINT `paper_decisions_ibfk_1` FOREIGN KEY (`paper_id`) REFERENCES `papers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `paper_decisions_ibfk_2` FOREIGN KEY (`decided_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paper_decisions`
--

LOCK TABLES `paper_decisions` WRITE;
/*!40000 ALTER TABLE `paper_decisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `paper_decisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paper_files`
--

DROP TABLE IF EXISTS `paper_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paper_files` (
  `id` int NOT NULL AUTO_INCREMENT,
  `paper_id` int NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int DEFAULT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `version_type` enum('original','blind','revision','camera_ready','supplementary') DEFAULT 'original',
  `version_number` int DEFAULT '1',
  `uploaded_by` int DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `paper_id` (`paper_id`),
  KEY `uploaded_by` (`uploaded_by`),
  CONSTRAINT `paper_files_ibfk_1` FOREIGN KEY (`paper_id`) REFERENCES `papers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `paper_files_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paper_files`
--

LOCK TABLES `paper_files` WRITE;
/*!40000 ALTER TABLE `paper_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `paper_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paper_reviews`
--

DROP TABLE IF EXISTS `paper_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paper_reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assignment_id` int NOT NULL,
  `paper_id` int NOT NULL,
  `reviewer_id` int NOT NULL,
  `score_originality` int DEFAULT NULL,
  `score_methodology` int DEFAULT NULL,
  `score_presentation` int DEFAULT NULL,
  `score_relevance` int DEFAULT NULL,
  `score_overall` int DEFAULT NULL,
  `comments_to_author` text,
  `comments_to_editor` text,
  `recommendation` enum('strong_accept','accept','minor_revision','major_revision','reject') DEFAULT NULL,
  `confidence` enum('low','medium','high') DEFAULT 'medium',
  `submitted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `assignment_id` (`assignment_id`),
  KEY `paper_id` (`paper_id`),
  KEY `reviewer_id` (`reviewer_id`),
  CONSTRAINT `paper_reviews_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `reviewer_assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `paper_reviews_ibfk_2` FOREIGN KEY (`paper_id`) REFERENCES `papers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `paper_reviews_ibfk_3` FOREIGN KEY (`reviewer_id`) REFERENCES `reviewers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `paper_reviews_chk_1` CHECK ((`score_originality` between 1 and 5)),
  CONSTRAINT `paper_reviews_chk_2` CHECK ((`score_methodology` between 1 and 5)),
  CONSTRAINT `paper_reviews_chk_3` CHECK ((`score_presentation` between 1 and 5)),
  CONSTRAINT `paper_reviews_chk_4` CHECK ((`score_relevance` between 1 and 5)),
  CONSTRAINT `paper_reviews_chk_5` CHECK ((`score_overall` between 1 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paper_reviews`
--

LOCK TABLES `paper_reviews` WRITE;
/*!40000 ALTER TABLE `paper_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `paper_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paper_tracks`
--

DROP TABLE IF EXISTS `paper_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paper_tracks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_th` varchar(255) DEFAULT NULL,
  `description` text,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paper_tracks`
--

LOCK TABLES `paper_tracks` WRITE;
/*!40000 ALTER TABLE `paper_tracks` DISABLE KEYS */;
INSERT INTO `paper_tracks` VALUES (6,'Artificial Intelligence in Education',NULL,'AI, Machine Learning, and Adaptive Learning systems',1,'2026-01-12 14:54:36'),(7,'Gamification & Game-based Learning',NULL,'Serious games, gamification strategies in education',1,'2026-01-12 14:54:36'),(8,'Online Learning Platforms',NULL,'LMS, MOOCs, and VLEs',1,'2026-01-12 14:54:36'),(9,'VR/AR in Education',NULL,'Virtual and Augmented Reality applications for learning',1,'2026-01-12 14:54:36');
/*!40000 ALTER TABLE `paper_tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papers`
--

DROP TABLE IF EXISTS `papers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `papers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `title_th` varchar(500) DEFAULT NULL,
  `abstract` text,
  `abstract_th` text,
  `keywords` varchar(255) DEFAULT NULL,
  `keywords_th` varchar(500) DEFAULT NULL,
  `track_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `submitter_id` int DEFAULT NULL,
  `track` varchar(100) DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `status` enum('draft','submitted','under_review','revision_required','revision_submitted','accepted','rejected','camera_ready','published') DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `decision_at` timestamp NULL DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_papers_status` (`status`),
  CONSTRAINT `papers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papers`
--

LOCK TABLES `papers` WRITE;
/*!40000 ALTER TABLE `papers` DISABLE KEYS */;
/*!40000 ALTER TABLE `papers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionnaire_responses`
--

DROP TABLE IF EXISTS `questionnaire_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questionnaire_responses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `questionnaire_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `session_token` varchar(100) NOT NULL,
  `status` enum('started','completed','abandoned') DEFAULT 'started',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `questionnaire_id` (`questionnaire_id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `questionnaire_responses_ibfk_1` FOREIGN KEY (`questionnaire_id`) REFERENCES `questionnaires` (`id`) ON DELETE CASCADE,
  CONSTRAINT `questionnaire_responses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `questionnaire_responses_ibfk_3` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionnaire_responses`
--

LOCK TABLES `questionnaire_responses` WRITE;
/*!40000 ALTER TABLE `questionnaire_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `questionnaire_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionnaires`
--

DROP TABLE IF EXISTS `questionnaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questionnaires` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `category` enum('pre-event','post-event','research','custom') DEFAULT 'pre-event',
  `target_type` enum('all','attendee','speaker','reviewer','author') DEFAULT 'all',
  `event_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `is_anonymous` tinyint(1) DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionnaires`
--

LOCK TABLES `questionnaires` WRITE;
/*!40000 ALTER TABLE `questionnaires` DISABLE KEYS */;
INSERT INTO `questionnaires` VALUES (1,'แบบสอบถาม event','ใช้ถาม User','pre-event','all',NULL,1,0,NULL,NULL,'2025-12-07 02:51:10','2025-12-10 07:31:38'),(4,'Post Event','','post-event','all',NULL,1,0,NULL,NULL,'2025-12-10 07:46:16','2025-12-10 07:46:16');
/*!40000 ALTER TABLE `questionnaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question_text` text NOT NULL,
  `type` enum('text','textarea','select','radio','checkbox','rating','date','number') DEFAULT 'text',
  `options` text,
  `category` enum('pre-event','post-event') NOT NULL,
  `is_required` tinyint(1) DEFAULT '0',
  `display_order` int DEFAULT '0',
  `placeholder` varchar(255) DEFAULT NULL,
  `min_value` int DEFAULT NULL,
  `max_value` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `questionnaire_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_questionnaire` (`questionnaire_id`),
  CONSTRAINT `fk_questionnaire` FOREIGN KEY (`questionnaire_id`) REFERENCES `questionnaires` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,'คุณมาจากประเทศไทยใช่ใหม','text',NULL,'pre-event',0,0,NULL,NULL,NULL,'2025-12-07 02:45:40',NULL),(2,'คุณแพ้อาหารอะไรบ้าง','text',NULL,'pre-event',1,0,NULL,NULL,NULL,'2025-12-07 02:53:30',1),(3,'ขอชื่อผู้เข้าร่วม','text',NULL,'pre-event',0,0,NULL,NULL,NULL,'2025-12-10 07:46:30',4);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registrations`
--

DROP TABLE IF EXISTS `registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `ticket_id` int NOT NULL,
  `status` enum('pending','paid','cancelled') DEFAULT 'pending',
  `payment_proof_url` varchar(255) DEFAULT NULL,
  `registered_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `checked_in_at` timestamp NULL DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ticket_id` (`ticket_id`),
  CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `registrations_ibfk_2` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrations`
--

LOCK TABLES `registrations` WRITE;
/*!40000 ALTER TABLE `registrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `registrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviewer_assignments`
--

DROP TABLE IF EXISTS `reviewer_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviewer_assignments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `paper_id` int NOT NULL,
  `reviewer_id` int NOT NULL,
  `assigned_by` int DEFAULT NULL,
  `status` enum('pending','accepted','declined','completed','expired') DEFAULT 'pending',
  `assigned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `responded_at` timestamp NULL DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `decline_reason` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_assignment` (`paper_id`,`reviewer_id`),
  KEY `reviewer_id` (`reviewer_id`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `reviewer_assignments_ibfk_1` FOREIGN KEY (`paper_id`) REFERENCES `papers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviewer_assignments_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `reviewers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviewer_assignments_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviewer_assignments`
--

LOCK TABLES `reviewer_assignments` WRITE;
/*!40000 ALTER TABLE `reviewer_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviewer_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviewers`
--

DROP TABLE IF EXISTS `reviewers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviewers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `expertise` varchar(255) DEFAULT NULL,
  `affiliation` varchar(255) DEFAULT NULL,
  `bio` text,
  `is_active` tinyint(1) DEFAULT '1',
  `total_assignments` int DEFAULT '0',
  `completed_reviews` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reviewers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviewers`
--

LOCK TABLES `reviewers` WRITE;
/*!40000 ALTER TABLE `reviewers` DISABLE KEYS */;
INSERT INTO `reviewers` VALUES (2,1,NULL,NULL,NULL,1,1,0,'2025-12-08 12:50:38','2026-01-12 14:56:40'),(3,8,'AI, Machine Learning','Chulalongkorn University',NULL,1,1,1,'2026-01-12 14:55:11','2026-01-12 15:14:19');
/*!40000 ALTER TABLE `reviewers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `paper_id` int NOT NULL,
  `reviewer_id` int NOT NULL,
  `rating` int DEFAULT NULL,
  `comment_to_author` text,
  `comment_confidential` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `paper_id` (`paper_id`),
  KEY `reviewer_id` (`reviewer_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`paper_id`) REFERENCES `papers` (`id`),
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `reviewers` (`id`),
  CONSTRAINT `reviews_chk_1` CHECK (((`rating` >= 1) and (`rating` <= 5)))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `settings` json DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (8,'Schedule of Technology:2026','Technology: 2026','2025-12-07 13:37:50','{\"days\": [\"2026-01-27\", \"2026-01-28\"], \"rooms\": [\"BallRoom-Hall\", \"BallRoom-01\"]}',7);
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_attachments`
--

DROP TABLE IF EXISTS `session_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` int NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_url` varchar(500) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `session_attachments_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_attachments`
--

LOCK TABLES `session_attachments` WRITE;
/*!40000 ALTER TABLE `session_attachments` DISABLE KEYS */;
INSERT INTO `session_attachments` VALUES (1,14,'file-sent.pdf','/uploads/1768293380992-file-sent.pdf','application/pdf','2026-01-13 08:36:20');
/*!40000 ALTER TABLE `session_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_speakers`
--

DROP TABLE IF EXISTS `session_speakers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_speakers` (
  `session_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`session_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `session_speakers_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `session_speakers_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_speakers`
--

LOCK TABLES `session_speakers` WRITE;
/*!40000 ALTER TABLE `session_speakers` DISABLE KEYS */;
INSERT INTO `session_speakers` VALUES (15,30),(17,31),(19,31),(22,34),(23,35),(27,36),(14,57);
/*!40000 ALTER TABLE `session_speakers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `room` varchar(100) DEFAULT NULL,
  `type` enum('keynote','panel','workshop','presentation','break') DEFAULT 'presentation',
  `schedule_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `fk_session_schedule` (`schedule_id`),
  CONSTRAINT `fk_session_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (12,NULL,'Open Event','','2025-12-07 09:00:00','2025-12-07 09:00:00','Room A','break',8),(13,7,'Registration & Coffee','Check-in and morning refreshments.','2026-01-27 08:00:00','2026-01-27 09:00:00','BallRoom-01','break',8),(14,7,'Opening Ceremony','Welcome address by the Conference Chair.','2026-01-27 09:00:00','2026-01-27 09:30:00','BallRoom-Hall','keynote',8),(15,7,'Keynote 1: AI Transforming Higher Education','Exploring the impact of Artificial Intelligence on university curriculums and teaching methods.','2026-01-27 10:45:00','2026-01-27 12:00:00','BallRoom-Hall','keynote',8),(16,7,'Morning Break','Networking and refreshments.','2026-01-27 10:30:00','2026-01-27 10:45:00','BallRoom-01','break',8),(17,7,'Panel Discussion: The Post-Digital University','Expert panel discussing the future of digital campuses.','2026-01-27 09:30:00','2026-01-27 10:30:00','BallRoom-Hall','panel',8),(18,7,'Networking Lunch','International buffet lunch.','2026-01-27 12:00:00','2026-01-27 13:30:00','Dining Hall','break',8),(19,7,'Parallel Session: Innovation in E-Learning','Technical presentations on new platform capabilities.','2026-01-27 13:30:00','2026-01-27 15:00:00','Room A','presentation',8),(20,7,'Parallel Session: Learning Analytics','Data-driven insights for student success.','2026-01-27 13:30:00','2026-01-27 15:00:00','Room B','presentation',8),(21,7,'Afternoon Break','Coffee and snacks.','2026-01-27 15:00:00','2026-01-27 15:30:00','BallRoom-01','break',8),(22,7,'Workshop: Generative AI for Teachers','Hands-on workshop on using GenAI tools in the classroom.','2026-01-27 15:30:00','2026-01-27 17:00:00','Workshop Room 1','workshop',8),(23,7,'Keynote 2: Future Skills for 2030','What skills will graduates need in the next decade?','2026-01-28 09:00:00','2026-01-28 10:30:00','BallRoom-Hall','keynote',8),(24,7,'Morning Break','Networking and refreshments.','2026-01-28 10:30:00','2026-01-28 10:45:00','BallRoom-01','break',8),(25,7,'Paper Presentations: Track A & B','Selected research paper presentations.','2026-01-28 10:45:00','2026-01-28 12:15:00','Room A & B','presentation',8),(26,7,'Lunch','Buffet lunch.','2026-01-28 12:15:00','2026-01-28 13:30:00','Dining Hall','break',8),(27,7,'Workshop: Building Interactive Courseware','Creating engaging online content.','2026-01-28 13:30:00','2026-01-28 15:00:00','Workshop Room 2','workshop',8),(28,7,'Closing Ceremony & Awards','Awards for best papers and closing remarks.','2026-01-28 15:00:00','2026-01-28 15:30:00','BallRoom-Hall','keynote',8),(29,NULL,'Test','','2026-01-27 09:00:00','2026-01-27 09:00:00','Room1','presentation',8);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  `setting_type` enum('text','textarea','image','json','boolean') DEFAULT 'text',
  `category` enum('general','header','footer','social','seo') DEFAULT 'general',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'site_name_en','ACMS Conference','text','general','2025-12-10 08:25:50'),(2,'site_name_th','ระบบจัดการงานประชุม','text','general','2025-12-10 08:25:50'),(3,'logo_url',NULL,'image','header','2025-12-10 08:25:50'),(4,'favicon_url',NULL,'image','general','2025-12-10 08:25:50'),(5,'contact_email','contact@acms.com','text','general','2025-12-10 08:25:50'),(6,'contact_phone','','text','general','2025-12-10 08:25:50'),(7,'contact_address','','textarea','footer','2025-12-10 08:25:50'),(8,'footer_copyright','© 2025 ACMS. All rights reserved.','text','footer','2025-12-10 08:25:50'),(9,'social_facebook','','text','social','2025-12-10 08:25:50'),(10,'social_twitter','','text','social','2025-12-10 08:25:50'),(11,'social_line','','text','social','2025-12-10 08:25:50'),(12,'social_youtube','','text','social','2025-12-10 08:25:50'),(13,'meta_title','ACMS - Conference Management System','text','seo','2025-12-10 08:25:50'),(14,'meta_description','Academic Conference Management System','textarea','seo','2025-12-10 08:25:50'),(15,'meta_keywords','conference, academic, management','text','seo','2025-12-10 08:25:50');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `speaker_group_members`
--

DROP TABLE IF EXISTS `speaker_group_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `speaker_group_members` (
  `group_id` int NOT NULL,
  `user_id` int NOT NULL,
  `display_order` int DEFAULT '0',
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `speaker_group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `speaker_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `speaker_group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `speaker_group_members`
--

LOCK TABLES `speaker_group_members` WRITE;
/*!40000 ALTER TABLE `speaker_group_members` DISABLE KEYS */;
INSERT INTO `speaker_group_members` VALUES (5,30,0),(5,31,0),(5,32,0),(5,34,0),(5,35,0),(5,36,0),(5,57,0);
/*!40000 ALTER TABLE `speaker_group_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `speaker_groups`
--

DROP TABLE IF EXISTS `speaker_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `speaker_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `speaker_groups_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `speaker_groups`
--

LOCK TABLES `speaker_groups` WRITE;
/*!40000 ALTER TABLE `speaker_groups` DISABLE KEYS */;
INSERT INTO `speaker_groups` VALUES (5,'Speakers of Technology:2026','Technology:2026','2025-12-07 13:33:26',7);
/*!40000 ALTER TABLE `speaker_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int NOT NULL DEFAULT '1',
  `badge_size` varchar(20) DEFAULT '8.6x5.4',
  `badge_orientation` varchar(20) DEFAULT 'landscape',
  `system_name` varchar(255) DEFAULT NULL,
  `description` text,
  `primary_color` varchar(7) DEFAULT NULL,
  `secondary_color` varchar(7) DEFAULT NULL,
  `logo_url` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `smtp_host` varchar(255) DEFAULT 'smtp.gmail.com',
  `smtp_port` varchar(10) DEFAULT '587',
  `smtp_user` varchar(255) DEFAULT NULL,
  `smtp_password` varchar(255) DEFAULT NULL,
  `smtp_from_email` varchar(255) DEFAULT NULL,
  `smtp_from_name` varchar(255) DEFAULT 'ACMS Conference',
  `smtp_secure` varchar(10) DEFAULT 'tls',
  `academic_conference_name` varchar(255) DEFAULT 'AMS Annual Conference 2026',
  `academic_submission_deadline` date DEFAULT NULL,
  `academic_review_deadline` date DEFAULT NULL,
  `academic_review_type` varchar(50) DEFAULT 'double_blind',
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_address` text,
  `social_facebook` varchar(255) DEFAULT NULL,
  `social_twitter` varchar(255) DEFAULT NULL,
  `social_linkedin` varchar(255) DEFAULT NULL,
  `contact_map_url` text,
  `social_youtube` varchar(255) DEFAULT NULL,
  `social_line` varchar(255) DEFAULT NULL,
  `social_whatsapp` varchar(255) DEFAULT NULL,
  `omise_public_key` varchar(255) DEFAULT NULL,
  `omise_secret_key` varchar(255) DEFAULT NULL,
  `omise_enabled` tinyint(1) DEFAULT '0',
  `stripe_publishable_key` varchar(255) DEFAULT NULL,
  `stripe_secret_key` varchar(255) DEFAULT NULL,
  `stripe_enabled` tinyint(1) DEFAULT '0',
  `payment_currency` varchar(3) DEFAULT 'THB',
  PRIMARY KEY (`id`),
  CONSTRAINT `system_settings_chk_1` CHECK ((`id` = 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'9x13','landscape','AMS 2025','Conference Management System','#2D4391','#4FDB90',NULL,'2025-12-07 14:46:29','2026-01-15 05:59:36','smtp.gmail.com','587',NULL,NULL,NULL,'ACMS Conference','tls','AMS Annual Conference 2026',NULL,NULL,'double_blind','0988721888','adin@lifeskill.in.th','Din Daeng Road, Khwaeng Din Daeng, Khet Din Daeng, Bangkok 10400, Thailand','https://www.facebook.com/#','https://x.com/#','https://www.linkedin.com/#','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3875.260043741693!2d100.54160328180969!3d13.763185562575693!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30e29e95a7412aab%3A0x8d99187de3c1ba32!2sLPN%20Suite%20Dindaeng%20-%20Rachaprarop!5e0!3m2!1sen!2sth!4v1768306113948!5m2!1sen!2sth','https://www.youtube.com/#','https://line.me/#','https://wa.me/#','pkey_test_66dqaa9n8du2vd7br2n','skey_test_66dqaaa3ocb62qt6zkv',1,'pk_live_51O5kQ5CptJvcLZlxaPUPQRmBeN7TAQKW0kaqqwCSPeOhxFgfHQuQc2nRmtEYnnFaUdPqBf6Hd4eqNQblnghichdV00CBXm17c3','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',1,'THB');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quota` int DEFAULT NULL,
  `available_until` datetime DEFAULT NULL,
  `background_image` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (7,7,'Student',0.00,NULL,NULL,'/uploads/cropped-1765167456577-ffpymh.jpg'),(8,7,'Personal',1000.00,NULL,NULL,'/uploads/cropped-1768405312114-zlfc9e.jpg');
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notifications`
--

DROP TABLE IF EXISTS `user_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `notification_id` int NOT NULL,
  `user_id` int NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `read_at` datetime DEFAULT NULL,
  `email_sent` tinyint(1) DEFAULT '0',
  `email_sent_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_notification_user` (`notification_id`,`user_id`),
  KEY `idx_user_notifications_user` (`user_id`),
  KEY `idx_user_notifications_read` (`is_read`),
  CONSTRAINT `user_notifications_ibfk_1` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_notifications_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notifications`
--

LOCK TABLES `user_notifications` WRITE;
/*!40000 ALTER TABLE `user_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `role` enum('admin','chair','reviewer','author','attendee','speaker') DEFAULT 'attendee',
  `profile_image` varchar(255) DEFAULT NULL,
  `bio` text,
  `organization` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `title` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `birth_year` int DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `address` text,
  `education_level` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@example.com','password','Admin','User','admin',NULL,NULL,NULL,'2025-11-24 03:18:36','2025-11-24 03:18:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'admin@acms.com','$2b$10$vyFfTwjqNzA3crYW.eVjhe1jzSmyxw76Re5a3MlkYGKOch6SKcahu','Admin','Yuanying','admin',NULL,'',NULL,'2025-12-07 02:17:19','2026-01-19 03:04:02','Dr.','Prefer not to say',NULL,'','','','','',''),(30,'sarah.connor@mit.edu','$2b$10$VqViiZ/DVxE31on.D2LXMOS5OUNCLbzW9JfQG4GjDToNxivyoTgnu','Kanyarat','Boteang','speaker','/uploads/speaker-30-1768794032782-speaker-profile.jpg','Professor at MIT, AI Researcher',NULL,'2026-01-13 07:35:09','2026-01-19 03:40:32','Dr.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Thailand'),(31,'james.wan@uni.edu','$2b$10$VqViiZ/DVxE31on.D2LXMOS5OUNCLbzW9JfQG4GjDToNxivyoTgnu','James','Wan','speaker','/uploads/speaker-31-1768794269251-speaker-profile.jpg','Digital Learning Specialist',NULL,'2026-01-13 07:35:09','2026-01-19 03:44:29','Prof.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,'linda.lee@tech.com','$2b$10$VqViiZ/DVxE31on.D2LXMOS5OUNCLbzW9JfQG4GjDToNxivyoTgnu','Linda','Lee','speaker','/uploads/speaker-32-1768793971260-speaker-profile.jpg','CEO of EdTech Innovations',NULL,'2026-01-13 07:35:09','2026-01-19 03:39:48','Dr.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Thailand'),(34,'david.brown@training.org','$2b$10$VqViiZ/DVxE31on.D2LXMOS5OUNCLbzW9JfQG4GjDToNxivyoTgnu','David','Intree','speaker','/uploads/speaker-34-1768794217575-speaker-profile.jpg','Professional Trainer in GenAI',NULL,'2026-01-13 07:35:09','2026-01-19 03:43:37','Asst. Prof. Dr.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,'michael.ross@future.org','$2b$10$VqViiZ/DVxE31on.D2LXMOS5OUNCLbzW9JfQG4GjDToNxivyoTgnu','Boontham','Boonraksa','speaker','/uploads/speaker-35-1768794245988-speaker-profile.jpg','Futurist and Educator',NULL,'2026-01-13 07:35:09','2026-01-19 03:44:05','Asst. Prof. Dr.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Thailand'),(36,'jessica.chen@interactive.io','$2b$10$VqViiZ/DVxE31on.D2LXMOS5OUNCLbzW9JfQG4GjDToNxivyoTgnu','Jessica','Chen','speaker','/uploads/speaker-36-1768793421137-speaker-profile.jpg','Instructional Designer',NULL,'2026-01-13 07:35:09','2026-01-19 03:41:35','Dr.','',NULL,'','','','','',NULL),(57,'yuanying@gmail.com','$2b$10$b4PAm8CmuKp0bz/rZceLOOkrK2R7X1BWZr4EhuKmpg4lY9s02M0BK','Yuan','Ying','speaker','/uploads/speaker-57-1768794055506-speaker-profile.jpg','Ai Automation, Education Tech',NULL,'2026-01-19 03:15:48','2026-01-19 03:40:55','Dr.','Female',NULL,'','','Doctorate','','','Chinese'),(58,'jira@lifeskill.in.th','$2b$10$U93Wy4u8akCMxAkx5dnaLuQ9kDdwQ/oF/hAjLJvBtPwCSIdxgw7Ai','Jira','Chonraksuk','attendee','/uploads/register-1768795052725-profile.jpg',NULL,NULL,'2026-01-19 03:57:32','2026-01-19 03:57:32','Dr.','Male',1986,'0988721888','558 Ratchadapisek Road, Din Daeng District, Bangkok, Thailand','Doctorate','AI, Education Technology','Lifeskill.co,.Ltd','Thailand');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-19 12:59:32
